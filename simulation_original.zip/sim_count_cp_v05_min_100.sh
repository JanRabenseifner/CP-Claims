#!/bin/bash
#SBATCH --partition=std
#SBATCH --ntasks=96
#SBATCH --cpus-per-task=1
#SBATCH --time=08:00:00
#SBATCH --job-name=count_cp_v05
#SBATCH --export=count_cp_v05
#SBATCH --output=/beegfs/u/baz9569/sim_count_cp/v05_output/slurm-%j.out
#SBATCH --error=/beegfs/u/baz9569/sim_count_cp/v05_errors/slurm-%j.err

set -e
set -x

# Setup
source /sw/batch/init.sh
module unload env
module load env/gcc-13.2.0_openmpi-4.1.6
source /usw/baz9569/anaconda3/bin/activate shapley_doubleml_2

# Environment variables
export MPLCONFIGDIR=/beegfs/u/baz9569/sim_count_cp/matplotlib
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

# Directories
BASE_DIR="/beegfs/u/baz9569/sim_count_cp/v05"
RESULTS_DIR="/beegfs/u/baz9569/sim_count_cp/v05_results/results_${SLURM_JOB_ID}"
export RESULTS_DIR

# Create directories matching SBATCH output/error paths
mkdir -p "$RESULTS_DIR"
mkdir -p /beegfs/u/baz9569/sim_count_cp/v05_errors
mkdir -p /beegfs/u/baz9569/sim_count_cp/v05_output
#mkdir -p "$MPLCONFIGDIR"

#cd "${BASE_DIR}/code"
cd /beegfs/u/baz9569/sim_count_cp/files/

echo "=============================================="
echo "v05 COUNT DATA CP SIMULATION"
echo "=============================================="
echo "Job ID: $SLURM_JOB_ID"
echo "Results dir: $RESULTS_DIR"
echo "Start time: $(date)"
echo "=============================================="

# Run simulation
mpirun python sim_count_cp_v05_min_100.py 2> /beegfs/u/baz9569/sim_count_cp/v05_errors/error_report_${SLURM_JOB_ID}.log

# Combine results
if [ $SLURM_PROCID -eq 0 ]; then
    echo "Combining results..."
    python -c "
import pandas as pd
import glob
import os

results_dir = '$RESULTS_DIR'
output_file = os.path.join(results_dir, 'results_combined.parquet')

# Find all result files
files = glob.glob(os.path.join(results_dir, '**', '*.parquet'), recursive=True)
print(f'Found {len(files)} result files')

# Combine
dfs = []
for f in files:
    try:
        dfs.append(pd.read_parquet(f))
    except Exception as e:
        print(f'Error reading {f}: {e}')

if dfs:
    combined = pd.concat(dfs, ignore_index=True)
    combined.to_parquet(output_file)
    print(f'Saved {len(combined)} rows to {output_file}')
    
    # Summary
    print(f'\\n=== SUMMARY ===')
    print(f'Methods: {combined[\"method\"].nunique()}')
    print(f'DGPs: {combined[\"dgp_type\"].nunique()}')
    print(f'Learners: {combined[\"learner\"].nunique()}')
    print(f'Repetitions: {combined[\"repetition\"].nunique()}')
    
    # Quick coverage stats
    if 'coverage' in combined.columns:
        cov_summary = combined.groupby('method')['coverage'].agg(['mean', 'std']).round(4)
        print(f'\\nCoverage by method:')
        print(cov_summary)
else:
    print('No results found!')
"
fi

echo "=============================================="
echo "Simulation completed at: $(date)"
echo "=============================================="