#!/usr/bin/env python
"""
Simulation Study for Count Data Conformal Prediction
"""

from mpi4py import MPI
import numpy as np
import pandas as pd
import warnings
import time
import os
import sys
from pathlib import Path
from typing import Dict, List, Any
import itertools
from scipy import stats


# Scikit-learn
from sklearn.ensemble import RandomForestRegressor
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OrdinalEncoder, StandardScaler
# Use k-means on selected features
from sklearn.cluster import KMeans


# Statsmodels
import statsmodels.api as sm

# LightGBM
try:
    from lightgbm import LGBMRegressor
    LGBM_AVAILABLE = True
except ImportError:
    LGBM_AVAILABLE = False
    print("Warning: LightGBM not available")


# Import DGP
from utils_dgps import EnhancedCountDGP

# Import existing utilities
from utils_dgps import split_data, summarize_dgp_output
from utils_pinterval import (
    poisson_parametric_interval, negbinom_parametric_interval,
    bootstrap_poisson_interval, discrete_conformal_poisson,
    mondrian_conformal_poisson, binary_classification_cp,
)
from utils_benchmarks import run_parametric_benchmarks
from utils_two_stage_4 import (
    two_stage_mixture_cp, two_stage_weighted_cp, two_stage_adaptive_cp, 
    two_stage_calibrated_cp, two_stage_balanced_cp, two_stage_dgcp_inspired_cp, two_stage_three_group_cp, 
    two_stage_direct_cp, two_stage_empirical_cp, two_stage_balanced_v2_cp,
    two_stage_exact_cp)
from utils_eval import (
    interval_coverage, interval_width, interval_score,
    outcome_conditional_coverage, actuarial_metrics
)

warnings.filterwarnings('ignore')

# MPI Setup
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

# =============================================================================
# SIMULATION CONFIGURATION
# =============================================================================

N_REPS = 96  # Increased for better variance estimation

# Distribute repetitions
reps_per_process = N_REPS // size
extra_reps = N_REPS % size

if rank < extra_reps:
    reps_per_process += 1
    start_rep = rank * reps_per_process
else:
    start_rep = rank * reps_per_process + extra_reps

end_rep = start_rep + reps_per_process

# Conformal prediction parameters
ALPHA = 0.1  # 90% coverage target

base_seed = 42

# Enhanced DGP parameter grids
DGP_TYPES = ['poisson', 'zip', 'negbin', 'hurdle']
N_OBS_LIST = [1000]  # Wider range
DIM_X_LIST = [10]  # More dimensions

# Covariate complexity
CORRELATION_TYPES = ['independent', 'toeplitz', 'block']
CORRELATION_STRENGTHS = [0.3]
CATEGORICAL_RATIOS = [0.3]

# Count distribution parameters
ZERO_INFLATION_LIST = [0.2]
OVERDISPERSION_LIST = [2.0]

min_group_size = 50

#N_OBS_LIST = [1000, 2000, 5000, 10000]  # Wider range
#DIM_X_LIST = [5, 10, 20, 50]  # More dimensions

# Covariate complexity
#CORRELATION_TYPES = ['independent', 'toeplitz', 'block']
#CORRELATION_STRENGTHS = [0.0, 0.3, 0.7]
#CATEGORICAL_RATIOS = [0.1, 0.3, 0.5]

# Count distribution parameters
#ZERO_INFLATION_LIST = [0.0, 0.2, 0.4, 0.6, 0.8]
#OVERDISPERSION_LIST = [1.0, 2.0, 5.0, 10.0]

# Data complexity flags
INTERACTION_EFFECTS = [True, False]
SPATIAL_EFFECTS = [True, False]
EXPOSURE_TYPES = ['uniform', 'realistic']

# Learners
LEARNER_NAMES = ['Poisson_GLM', 'LightGBM', 'RandomForest']

# CP Methods (12 methods as specified)
CP_METHODS = [
    'ICP_poisson_deviance',
    'ICP_za_relative',
    'Mondrian_Poisson',
    'Binary_CP_Marginal',
    'Binary_CP_Mondrian',
    #'Two_Stage_Mixture_CP',
    #'Two_Stage_Weighted_CP',
    #'Two_Stage_Adaptive_CP',
    #'Two_Stage_Calibrated_CP',
    #'Two_Stage_Balanced_CP',
    #'Two_Stage_DGCP_Inspired_CP',
    #'Two_Stage_Three_Group_CP',
    #'Two_Stage_Balanced_CP_v02',
    #'Two_Stage_Direct_CP',
    #'Two_Stage_Empirical_CP',
    #'Two_Stage_Exact_CP',
    'Poisson_Normal',
    'Poisson_Bootstrap',
    'NB_Chebyshev',
    'NB_Bootstrap',
    'NB_PlugIn',
]

# =============================================================================
# ENHANCED EVALUATION METRICS
# =============================================================================

def computemetrics(y_true, lower, upper, pred_mu, alpha=0.1):
    """Compute insurance-specific metrics"""
    
    # Basic metrics
    covered = (y_true >= lower) & (y_true <= upper)
    widths = upper - lower
    
    metrics = {
        'coverage': np.mean(covered),
        'mean_width': np.mean(widths),
        'median_width': np.median(widths),
        'width_std': np.std(widths),
        'interval_score': interval_score(y_true, lower, upper, alpha),
        'pct_singleton': 100 * np.mean(widths == 0),
    }
    
    # Outcome-conditional coverage - basic groups
    # Always report counts, use NaN for coverage when no observations
    y0_mask = (y_true == 0)
    y1_mask = (y_true == 1)
    y2plus_mask = (y_true >= 2)
    
    metrics['n_y0'] = int(y0_mask.sum())
    metrics['n_y1'] = int(y1_mask.sum())
    metrics['n_y2plus'] = int(y2plus_mask.sum())
    
    # Compute coverage only if we have enough observations (at least 5)
    min_obs_for_coverage = 5
    
    if y0_mask.sum() >= min_obs_for_coverage:
        metrics['coverage_y0'] = np.mean(covered[y0_mask])
    else:
        metrics['coverage_y0'] = np.nan
        
    if y1_mask.sum() >= min_obs_for_coverage:
        metrics['coverage_y1'] = np.mean(covered[y1_mask])
    else:
        metrics['coverage_y1'] = np.nan
        
    if y2plus_mask.sum() >= min_obs_for_coverage:
        metrics['coverage_y2plus'] = np.mean(covered[y2plus_mask])
    else:
        metrics['coverage_y2plus'] = np.nan
    
    # Coverage gap (only if both groups have enough observations)
    if metrics['n_y0'] >= min_obs_for_coverage and metrics['n_y1'] >= min_obs_for_coverage:
        metrics['coverage_gap'] = abs(metrics['coverage_y0'] - metrics['coverage_y1'])
    else:
        metrics['coverage_gap'] = np.nan
    
    # Binned outcome-conditional coverage (adaptive based on data)
    # Define bins: [1-5], [6-10], [11-20], [21-50], [51+]
    bin_edges = [(1, 5), (6, 10), (11, 20), (21, 50), (51, np.inf)]
    max_y = int(np.max(y_true)) if len(y_true) > 0 else 0
    
    for low, high in bin_edges:
        if max_y >= low:  # Only compute if bin could have data
            if np.isinf(high):
                bin_mask = (y_true >= low)
                bin_name = f'coverage_y{int(low)}plus'
            else:
                bin_mask = (y_true >= low) & (y_true <= high)
                bin_name = f'coverage_y{int(low)}_{int(high)}'
            
            if bin_mask.any():
                metrics[bin_name] = np.mean(covered[bin_mask])
                metrics[f'n_y{int(low)}_{int(high) if not np.isinf(high) else "plus"}'] = int(bin_mask.sum())
    
    # Risk differentiation
    if len(pred_mu) > 1:
        metrics['risk_differentiation'] = np.corrcoef(pred_mu, widths)[0, 1]
    
    # Insurance-specific metrics
    # 1. Value-at-Risk (VaR) coverage
    var_levels = [0.95, 0.99]
    for var_level in var_levels:
        var_threshold = np.percentile(y_true, var_level * 100)
        var_mask = (y_true >= var_threshold)
        if var_mask.any():
            metrics[f'var_{int(var_level*100)}_coverage'] = np.mean(covered[var_mask])
    
    # 2. Tail width assessment
    tail_mask = (y_true >= np.percentile(y_true, 90))
    if tail_mask.any():
        metrics['tail_mean_width'] = np.mean(widths[tail_mask])
        metrics['tail_coverage'] = np.mean(covered[tail_mask])
    
    # 3. Efficiency ratio (informativeness)
    # Proportion of intervals that are not [0, inf)
    informative = (lower > 0) | (upper < np.inf)
    metrics['pct_informative'] = 100 * np.mean(informative)
    
    # 4. Calibration by risk groups
    risk_deciles = pd.qcut(pred_mu, q=10, duplicates='drop', labels=False)
    calibration_by_risk = []
    for decile in np.unique(risk_deciles):
        decile_mask = (risk_deciles == decile)
        if decile_mask.any():
            decile_coverage = np.mean(covered[decile_mask])
            calibration_by_risk.append(decile_coverage)
    
    metrics['calibration_range'] = np.max(calibration_by_risk) - np.min(calibration_by_risk) if calibration_by_risk else np.nan
    
    return metrics


# =============================================================================
# LEARNER DEFINITIONS
# =============================================================================

def fit_poisson_glm(train_data: pd.DataFrame, valid_vars: List[str]):
    """Fit Poisson GLM and return prediction function."""
    X_train = pd.get_dummies(train_data[valid_vars], drop_first=True, dtype=float)
    X_train = sm.add_constant(X_train)
    
    model = sm.GLM(
        train_data["Claims"], X_train,
        family=sm.families.Poisson(),
        exposure=train_data["Exposure"]
    )
    
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            model_result = model.fit(maxiter=100)
        except:
            # Fallback with regularization
            model_result = model.fit_regularized(alpha=0.01)
    
    def predict(data_subset):
        X = pd.get_dummies(data_subset[valid_vars], drop_first=True, dtype=float)
        X = sm.add_constant(X)
        for col in model_result.model.exog_names:
            if col not in X.columns:
                X[col] = 0
        X = X[model_result.model.exog_names]
        return np.clip(model_result.predict(X) * data_subset["Exposure"].values, 1e-6, 100)
    
    return predict


def fit_lgbm(train_data: pd.DataFrame, valid_vars: List[str]):
    """Fit LightGBM Poisson model and return prediction function."""
    if not LGBM_AVAILABLE:
        raise ImportError("LightGBM not available")
    
    # Identify column types
    num_cols = [v for v in valid_vars if train_data[v].dtype.name != 'category'
               and np.issubdtype(train_data[v].dtype, np.number)]
    cat_cols = [v for v in valid_vars if v not in num_cols]
    
    # Preprocessor
    transformers = []
    if num_cols:
        transformers.append(("num", "passthrough", num_cols))
    if cat_cols:
        transformers.append(("cat", OrdinalEncoder(handle_unknown='use_encoded_value', 
                                                    unknown_value=-1), cat_cols))
    
    preprocessor = ColumnTransformer(
        transformers=transformers,
        verbose_feature_names_out=False,
    ).set_output(transform="pandas")
    
    # Fit preprocessor
    X_train = preprocessor.fit_transform(train_data[valid_vars])
    y_train = train_data["Claims"] / train_data["Exposure"]
    weights_train = train_data["Exposure"]
    
    # LightGBM model
    lgb_model = LGBMRegressor(
        objective="poisson",
        learning_rate=0.05,
        num_leaves=31,
        reg_lambda=2.0,
        reg_alpha=2.0,
        n_estimators=200,
        random_state=42,
        verbosity=-1
    )
    lgb_model.fit(X_train, y_train, sample_weight=weights_train)
    
    def predict(data_subset):
        X = preprocessor.transform(data_subset[valid_vars])
        return np.clip(lgb_model.predict(X) * data_subset["Exposure"].values, 1e-6, 100)
    
    return predict


def fit_random_forest(train_data: pd.DataFrame, valid_vars: List[str]):
    """Fit Random Forest Poisson model and return prediction function."""
    # Identify column types
    num_cols = [v for v in valid_vars if train_data[v].dtype.name != 'category'
               and np.issubdtype(train_data[v].dtype, np.number)]
    cat_cols = [v for v in valid_vars if v not in num_cols]
    
    # Preprocessor
    transformers = []
    if num_cols:
        transformers.append(("num", "passthrough", num_cols))
    if cat_cols:
        transformers.append(("cat", OrdinalEncoder(handle_unknown='use_encoded_value',
                                                    unknown_value=-1), cat_cols))
    
    preprocessor = ColumnTransformer(
        transformers=transformers,
        verbose_feature_names_out=False,
    ).set_output(transform="pandas")
    
    # Fit preprocessor
    X_train = preprocessor.fit_transform(train_data[valid_vars])
    y_train = train_data["Claims"] / train_data["Exposure"]
    weights_train = train_data["Exposure"]
    
    # Random Forest model
    rf_model = RandomForestRegressor(
        criterion="poisson",
        n_estimators=100,
        max_features="sqrt",
        max_depth=10,
        min_samples_leaf=20,
        random_state=42,
        n_jobs=1  # Single thread for MPI
    )
    rf_model.fit(X_train, y_train, sample_weight=weights_train)
    
    def predict(data_subset):
        X = preprocessor.transform(data_subset[valid_vars])
        return np.clip(rf_model.predict(X) * data_subset["Exposure"].values, 1e-6, 100)
    
    return predict


LEARNER_FUNCTIONS = {
    'Poisson_GLM': fit_poisson_glm,
    'LightGBM': fit_lgbm,
    'RandomForest': fit_random_forest
}

# =============================================================================
# ENHANCED CLUSTER GENERATION
# =============================================================================

def generate_meaningful_clusters(df, n_clusters=5):
    """
    Generate clusters based on insurance-relevant groupings
    """
    cluster_features = []
    
    # Try to identify meaningful features
    for col in df.columns:
        if col.startswith('Region'):
            cluster_features.append(col)
        elif col.startswith('Coverage'):
            cluster_features.append(col)
        elif 'age' in col.lower():
            cluster_features.append(col)
    
    if not cluster_features:
        # Fallback: use first numeric column
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            cluster_features = [numeric_cols[0]]
        else:
            # Last resort: constant cluster
            return np.ones(len(df))
    
    cluster_data = pd.get_dummies(df[cluster_features], drop_first=True).values
    
    # Handle small sample size
    n_clusters = min(n_clusters, len(cluster_data) // 10, 10)
    
    if len(cluster_data) >= n_clusters:
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        clusters = kmeans.fit_predict(cluster_data) + 1
    else:
        clusters = np.ones(len(df))
    
    return clusters

# =============================================================================
# MAIN SIMULATION LOOP (ENHANCED)
# =============================================================================

def runsimulation(config):
    """Run single simulation with features"""
    
    dgp = EnhancedCountDGP(seed=config['seed'])
    
    # Generate covariates with specified complexity
    df = dgp.generate_covariates(
        n_obs=config['n_obs'],
        dim_x=config['dim_x'],
        correlation_type=config['correlation_type'],
        categorical_ratio=config['categorical_ratio'],
        correlation_strength=config['correlation_strength']
    )
    
    # Generate exposure
    exposure = dgp.generate_exposure(
        n_obs=config['n_obs'],
        exposure_type=config['exposure_type']
    )
    
    # Generate claims
    y, mu_true, dgp_info = dgp.generate_claims(
        df=df,
        exposure=exposure,
        dgp_type=config['dgp_type'],
        zero_inflation=config['zero_inflation'],
        overdispersion=config['overdispersion'],
        interaction_effects=config['interaction_effects'],
        spatial_effects=config['spatial_effects']
    )
    
    # Add to DataFrame
    df['Claims'] = y
    df['Exposure'] = exposure
    df['pred_mu_true'] = mu_true
    
    # Split data
    data_splits = split_data(
        {'df': df, 'params': config},
        train_frac=0.6,
        calib_frac=0.2,
        seed=config['seed']
    )
    
    train_data = data_splits['train']
    calib_data = data_splits['calib']
    test_data = data_splits['test']
    
    # Generate meaningful clusters
    train_data['Cluster'] = generate_meaningful_clusters(train_data)
    calib_data['Cluster'] = generate_meaningful_clusters(calib_data)
    test_data['Cluster'] = generate_meaningful_clusters(test_data)
    
    # =========================================================================
    # MAIN SIMULATION LOGIC (adapted from sim_count_cp.py)
    # =========================================================================
    
    results = []
    
    # Identify valid variables for modeling
    all_cols = list(train_data.columns)
    exclude_cols = ['Claims', 'Exposure', 'pred_mu_true', 'pi_true', 'Cluster']
    valid_vars = [c for c in all_cols if c not in exclude_cols]
    
    # Loop over learners
    for learner_name in LEARNER_NAMES:
        if learner_name == 'LightGBM':
            try:
                import lightgbm
            except ImportError:
                continue

        try:
            # Fit learner (using the original learner functions from sim_count_cp.py)
            if learner_name == 'Poisson_GLM':
                predict_func = fit_poisson_glm(train_data, valid_vars)
            elif learner_name == 'LightGBM':
                predict_func = fit_lgbm(train_data, valid_vars)
            elif learner_name == 'RandomForest':
                predict_func = fit_random_forest(train_data, valid_vars)
            else:
                continue
            
            # Generate predictions
            calib_data_copy = calib_data.copy()
            test_data_copy = test_data.copy()
            
            calib_data_copy['pred_mu'] = predict_func(calib_data_copy)
            test_data_copy['pred_mu'] = predict_func(test_data_copy)
            
            # Extract arrays
            pred_mu = test_data_copy['pred_mu'].values
            calib_mu = calib_data_copy['pred_mu'].values
            calib_y = calib_data_copy['Claims'].values
            test_y = test_data_copy['Claims'].values
            calib_cluster = calib_data_copy['Cluster'].values
            test_cluster = test_data_copy['Cluster'].values
            
            # Run CP methods (adapted from run_cp_methods in sim_count_cp.py)
            cp_results = {}
            
            # Run parametric benchmarks from utils_benchmarks
            # NOTE: These fit their own Poisson/NB GLM models internally,
            # so results are the same across all learners. Only run once per config.
            if learner_name == 'Poisson_GLM':  # Only run benchmarks for first learner
                try:
                    benchmark_vars = [v for v in train_data.columns if v not in ['Claims', 'Exposure', 'Cluster', 'pred_mu', 'pred_mu_true']]
                    benchmarks = run_parametric_benchmarks(
                        train_data, calib_data, test_data, benchmark_vars, ALPHA
                    )
                    # Add benchmark results to cp_results (exclude internal keys starting with '_')
                    for key, value in benchmarks.items():
                        if not key.startswith('_'):
                            cp_results[key] = value
                except Exception as e:
                    print(f"Error in run_parametric_benchmarks: {e}")
                    import traceback
                    traceback.print_exc()
                    cp_results['Poisson_Normal'] = None
                    cp_results['Poisson_Bootstrap'] = None
                    cp_results['NB_Chebyshev'] = None
                    cp_results['NB_Bootstrap'] = None
                    cp_results['NB_PlugIn'] = None
            
            # 4. ICP with Poisson Deviance NCS
            try:
                intervals = discrete_conformal_poisson(pred_mu, calib_mu, calib_y, ALPHA, 'poisson_deviance')
                cp_results['ICP_poisson_deviance'] = intervals
            except Exception as e:
                cp_results['ICP_poisson_deviance'] = None
            
            # 5. ICP with ZA Relative NCS
            try:
                intervals = discrete_conformal_poisson(pred_mu, calib_mu, calib_y, ALPHA, 'za_relative')
                cp_results['ICP_za_relative'] = intervals
            except Exception as e:
                cp_results['ICP_za_relative'] = None
            
            # 6. Mondrian CP (cluster-conditional)
            try:
                intervals = mondrian_conformal_poisson(
                    pred_mu, test_cluster, calib_mu, calib_y, calib_cluster, ALPHA, 'poisson_deviance'
                )
                cp_results['Mondrian_Poisson'] = intervals
            except Exception as e:
                cp_results['Mondrian_Poisson'] = None
            
            # 7. Two-Stage Mixture CP

            try:
                intervals = two_stage_balanced_v2_cp(pred_mu, calib_mu, calib_y, ALPHA)
                cp_results['Two_Stage_Balanced_V2_CP'] = intervals
            except Exception as e:
                print(f"Error in Two_Stage_Balanced_V2_CP: {e}")
                cp_results['Two_Stage_Balanced_V2_CP'] = None

            try:
                intervals = two_stage_direct_cp(pred_mu, calib_mu, calib_y, ALPHA)
                cp_results['Two_Stage_Direct_CP'] = intervals
            except Exception as e:
                print(f"Error in Two_Stage_Direct_CP: {e}")
                cp_results['Two_Stage_Direct_CP'] = None

            # 8. Two-Stage Weighted CP (Corrected)
            try:
                intervals = two_stage_empirical_cp(pred_mu, calib_mu, calib_y, ALPHA)
                cp_results['Two_Stage_Empirical_CP'] = intervals
            except Exception as e:
                print(f"Error in Two_Stage_Empirical_CP: {e}")
                cp_results['Two_Stage_Empirical_CP'] = None

            # 8. Two-Stage Weighted CP (Corrected)

            try:
                intervals = two_stage_weighted_cp(pred_mu, calib_mu, calib_y, ALPHA)
                cp_results['Two_Stage_Weighted_CP'] = intervals
            except Exception as e:
                print(f"Error in Two_Stage_Weighted_CP: {e}")
                cp_results['Two_Stage_Weighted_CP'] = None

            # 10. Two-Stage Calibrated CP (Robust fallback)
            try:
                intervals = two_stage_calibrated_cp(pred_mu, calib_mu, calib_y, ALPHA)
                cp_results['Two_Stage_Calibrated_CP'] = intervals
            except Exception as e:
                print(f"Error in Two_Stage_Calibrated_CP: {e}")
                cp_results['Two_Stage_Calibrated_CP'] = None

            # 10. Two-Stage Calibrated CP (Robust fallback)
            #try:
            #    intervals = two_stage_exact_cp(pred_mu, calib_mu, calib_y, ALPHA, min_group_size=min_group_size)
            #    cp_results['Two_Stage_Exact_CP'] = intervals
            #except Exception as e:
            #    print(f"Error in Two_Stage_Exact_CP: {e}")
            #    cp_results['Two_Stage_Exact_CP'] = None
            
            
            
            # 11-12. Binary CP methods
            calib_y_binary = (calib_y > 0).astype(int)
            test_y_binary = (test_y > 0).astype(int)
            
            calib_probs = np.column_stack([np.exp(-calib_mu), 1 - np.exp(-calib_mu)])
            test_probs = np.column_stack([np.exp(-pred_mu), 1 - np.exp(-pred_mu)])
            
            try:
                binary_sets = binary_classification_cp(test_probs, calib_probs, calib_y_binary, ALPHA, mondrian=False)
                cp_results['Binary_CP_Marginal'] = binary_sets
            except Exception as e:
                print(f"Error in Binary_CP_Marginal: {e}")
            
            try:
                binary_sets = binary_classification_cp(test_probs, calib_probs, calib_y_binary, ALPHA, mondrian=True)
                cp_results['Binary_CP_Mondrian'] = binary_sets
            except Exception as e:
                print(f"Error in Binary_CP_Mondrian: {e}")
            
            # Evaluate results with metrics
            for method_name, result in cp_results.items():
                if result is None:
                    # Record error
                    row = {
                        'method': method_name,
                        'learner': learner_name,
                        'error': 'Method failed',
                        'repetition': config.get('repetition', 0),
                        **config
                    }
                    results.append(row)
                    continue
                
                # Handle binary CP methods differently
                if method_name in ['Binary_CP_Marginal', 'Binary_CP_Mondrian']:
                    # Binary methods return prediction sets
                    test_y_binary = (test_y > 0).astype(int)
                    
                    # Compute coverage (true label in set)
                    covered = np.array([y in s for y, s in zip(test_y_binary, result)])
                    set_sizes = np.array([len(s) for s in result])
                    
                    # Basic metrics
                    coverage = np.mean(covered)
                    mean_width = np.mean(set_sizes)
                    
                    # Outcome-conditional coverage
                    cov_y0 = np.mean(covered[test_y == 0]) if (test_y == 0).sum() > 0 else np.nan
                    cov_y1 = np.mean(covered[test_y >= 1]) if (test_y >= 1).sum() > 0 else np.nan
                    
                    # Convert to intervals for metrics
                    # For binary CP, we create approximate intervals
                    # 0 in set -> [0,0], 1 in set -> [1, max_count]
                    lower = np.zeros(len(test_y))
                    upper = np.zeros(len(test_y))
                    
                    for i, (s, mu) in enumerate(zip(result, pred_mu)):
                        if 0 in s and 1 in s:
                            lower[i] = 0
                            upper[i] = max(stats.poisson.ppf(1 - ALPHA/2, mu), 1)
                        elif 0 in s:
                            lower[i] = 0
                            upper[i] = 0
                        else:  # Only 1 in s
                            lower[i] = 1
                            upper[i] = max(stats.poisson.ppf(1 - ALPHA/2, mu), 1)
                    
                    # Compute metrics
                    metrics = computemetrics(test_y, lower, upper, pred_mu, ALPHA)
                    
                    row = {
                        'method': method_name,
                        'learner': learner_name,
                        'coverage': coverage,
                        'mean_width': mean_width,
                        'median_width': np.median(set_sizes),
                        'coverage_y0': cov_y0,
                        'coverage_y1': cov_y1,
                        'coverage_claims_0': cov_y0,  # For compatibility
                        'coverage_claims_1': cov_y1,
                        'pct_singleton': 100 * np.mean(set_sizes == 1),
                        'repetition': config.get('repetition', 0),
                        'min_group_size': min_group_size,
                        **config,
                        **metrics
                    }
                    
                else:
                    # Interval methods
                    if 'lower' in result.columns:
                        lower = result['lower'].values
                        upper = result['upper'].values
                    else:
                        lower = result['lower_bound'].values
                        upper = result['upper_bound'].values
                    
                    # Compute metrics
                    metrics = computemetrics(test_y, lower, upper, pred_mu, ALPHA)
                    
                    # Basic metrics for compatibility
                    widths = upper - lower
                    covered = (test_y >= lower) & (test_y <= upper)
                    
                    # Outcome-conditional coverage
                    cov_y0 = np.mean(covered[test_y == 0]) if (test_y == 0).sum() > 0 else np.nan
                    cov_y1 = np.mean(covered[test_y == 1]) if (test_y == 1).sum() > 0 else np.nan
                    cov_y2plus = np.mean(covered[test_y >= 2]) if (test_y >= 2).sum() > 0 else np.nan
                    
                    row = {
                        'method': method_name,
                        'learner': learner_name,
                        'coverage': metrics['coverage'],
                        'mean_width': metrics['mean_width'],
                        'median_width': metrics['median_width'],
                        'coverage_y0': cov_y0,
                        'coverage_y1': cov_y1,
                        'coverage_y2plus': cov_y2plus,
                        'coverage_claims_0': cov_y0,  # For compatibility
                        'coverage_claims_1': cov_y1,
                        'coverage_claims_2plus': cov_y2plus,
                        'pct_singleton': metrics['pct_singleton'],
                        'repetition': config.get('repetition', 0),
                        'min_group_size': min_group_size,
                        **config,
                        **metrics
                    }
                
                # Add DGP statistics
                dgp_summary = summarize_dgp_output({'y': y, 'mu': mu_true})
                row.update({
                    'pct_zeros_data': dgp_summary['pct_zeros'],
                    'mean_y_data': dgp_summary['mean_y'],
                    'var_y_data': dgp_summary['var_y'],
                    'dispersion_ratio': dgp_summary['dispersion_ratio']
                })
                
                results.append(row)
        
        except Exception as e:
            # Log error but continue
            error_row = {
                'learner': learner_name,
                'error': str(e),
                'repetition': config.get('repetition', 0),
                **config
            }
            results.append(error_row)
    
    return results

# =============================================================================
# CONFIGURATION GENERATOR
# =============================================================================

def generate_simulation_configs():
    """Generate comprehensive simulation configurations"""
    
    configs = []
    
    # Reduced but meaningful grid
    param_grid = {
        'dgp_type': DGP_TYPES,
        'n_obs': [1000, 2000, 4000, 6000, 10000],  # Focus on mid-range 2000, 5000, 
        'dim_x': [10, 20, 50],
        'correlation_type': ['toeplitz'],
        'correlation_strength': [0.0, 0.3, 0.5],
        'categorical_ratio': [0.1, 0.3, 0.5],
        'exposure_type': ['realistic'],
        'interaction_effects': [False,True],
        'spatial_effects': [False,True],
    }
    
    # Generate base configurations
    keys, values = zip(*param_grid.items())
    for i, combination in enumerate(itertools.product(*values)):
        config = dict(zip(keys, combination))
        
        # Add DGP-specific parameters
        if config['dgp_type'] in ['zip', 'hurdle']:
            config['zero_inflation'] = np.random.choice([0.0, 0.1, 0.3, 0.5])
        else:
            config['zero_inflation'] = 0.0
        
        if config['dgp_type'] == 'negbin':
            config['overdispersion'] = np.random.choice([2.0, 3.0, 4.0, 5.0])
        else:
            config['overdispersion'] = 1.0
        
        configs.append(config)
    
    return configs

# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    start_time = time.time()
    
    if rank == 0:
        print("=" * 80)
        print("ENHANCED COUNT DATA CONFORMAL PREDICTION SIMULATION")
        print("=" * 80)
        print(f"MPI Processes: {size}")
        print(f"Total Repetitions: {N_REPS}")
        print(f"Start Time: {time.ctime()}")
        print("=" * 80)
    
    # Generate simulation configurations
    all_configs = generate_simulation_configs()
    
    # Assign configurations to this rank
    configs_per_rep = len(all_configs)
    total_sims = N_REPS * configs_per_rep
    sims_per_process = total_sims // size
    
    results = []
    
    for rep in range(start_rep, end_rep):
        for config_idx, base_config in enumerate(all_configs):
            sim_config = base_config.copy()
            sim_config['seed'] = base_seed + rep * 1000 + config_idx
            sim_config['repetition'] = rep
            
            try:
                sim_results = runsimulation(sim_config)
                results.extend(sim_results)
            except Exception as e:
                print(f"Rank {rank}: Error in rep {rep}, config {config_idx}: {e}")
                continue
    
    # Save results
    df_results = pd.DataFrame(results)
    
    # Create output directory
    output_dir = Path(os.getenv('RESULTS_DIR', '.')) / f"rank_{rank:03d}"
    output_dir.mkdir(parents=True, exist_ok=True)
    
    output_file = output_dir / f"results_{rank:03d}.parquet"
    df_results.to_parquet(output_file)
    
    print(f"Rank {rank}: Saved {len(df_results)} results to {output_file}")
    
    # Synchronize and combine
    comm.Barrier()
    
    if rank == 0:
        print("\nCombining results from all ranks...")
        # Combination logic here
        
    print(f"Rank {rank}: Completed in {time.time() - start_time:.1f} seconds")