"""
Analysis and Visualization of Simulation Results
=================================================

This script analyzes the results from the conformal prediction simulation study.
It produces publication-ready tables and figures.

Author: Simulation Study for Conformal Prediction
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from typing import Dict, List, Optional
import warnings

warnings.filterwarnings('ignore')

# Set plotting style
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("colorblind")


# =============================================================================
# LOAD AND PREPROCESS RESULTS
# =============================================================================

def load_results(filepath: str) -> pd.DataFrame:
    """Load simulation results from pickle or CSV."""
    if filepath.endswith('.pkl'):
        df = pd.read_pickle(filepath)
    else:
        df = pd.read_csv(filepath)
    
    # Filter out error rows
    if 'error' in df.columns:
        df = df[df['error'].isna()].copy()
    
    return df


def preprocess_results(df: pd.DataFrame) -> pd.DataFrame:
    """Preprocess results for analysis."""
    # Ensure numeric columns
    numeric_cols = ['coverage', 'mean_width', 'median_width', 'interval_score',
                    'coverage_claims_0', 'coverage_claims_1', 'coverage_claims_2plus',
                    'coverage_gap', 'risk_differentiation', 'pct_singleton']
    
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # Create validity indicator (coverage >= 90% - 2%)
    df['is_valid'] = df['coverage'] >= 0.88
    
    return df


# =============================================================================
# SUMMARY STATISTICS
# =============================================================================

def compute_summary_stats(df: pd.DataFrame) -> pd.DataFrame:
    """Compute summary statistics across all simulation configurations."""
    
    summary = df.groupby(['dgp_type', 'learner', 'method']).agg({
        'coverage': ['mean', 'std', 'min', 'max'],
        'mean_width': ['mean', 'std'],
        'coverage_claims_0': ['mean', 'std'],
        'coverage_claims_1': ['mean', 'std'],
        'coverage_gap': ['mean', 'std'],
        'interval_score': ['mean', 'std'],
        'is_valid': ['mean']  # Proportion of valid runs
    }).round(4)
    
    # Flatten column names
    summary.columns = ['_'.join(col).strip() for col in summary.columns.values]
    summary = summary.reset_index()
    
    return summary


def compute_method_rankings(df: pd.DataFrame) -> pd.DataFrame:
    """Rank methods by different criteria."""
    
    rankings = []
    
    for (dgp, learner), group in df.groupby(['dgp_type', 'learner']):
        method_stats = group.groupby('method').agg({
            'coverage': 'mean',
            'mean_width': 'mean',
            'interval_score': 'mean',
            'coverage_gap': 'mean'
        }).reset_index()
        
        # Rank by different criteria
        method_stats['rank_coverage'] = method_stats['coverage'].rank(ascending=False)
        method_stats['rank_width'] = method_stats['mean_width'].rank(ascending=True)
        method_stats['rank_is'] = method_stats['interval_score'].rank(ascending=True)
        method_stats['rank_gap'] = method_stats['coverage_gap'].rank(ascending=True)
        
        # Combined rank (average of all ranks)
        method_stats['rank_combined'] = (
            method_stats['rank_coverage'] + 
            method_stats['rank_width'] + 
            method_stats['rank_is'] +
            method_stats['rank_gap']
        ) / 4
        
        method_stats['dgp_type'] = dgp
        method_stats['learner'] = learner
        rankings.append(method_stats)
    
    return pd.concat(rankings, ignore_index=True)


# =============================================================================
# VISUALIZATION FUNCTIONS
# =============================================================================

def plot_coverage_by_dgp(df: pd.DataFrame, output_dir: str = '.'):
    """Plot coverage comparison across DGPs."""
    
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    axes = axes.flatten()
    
    dgps = df['dgp_type'].unique()
    
    for idx, dgp in enumerate(dgps):
        ax = axes[idx]
        subset = df[df['dgp_type'] == dgp]
        
        # Aggregate across learners and repetitions
        method_cov = subset.groupby('method')['coverage'].agg(['mean', 'std']).reset_index()
        method_cov = method_cov.sort_values('mean', ascending=True)
        
        # Plot
        colors = ['green' if m >= 0.88 else 'red' for m in method_cov['mean']]
        bars = ax.barh(method_cov['method'], method_cov['mean'], 
                       xerr=method_cov['std'], color=colors, alpha=0.7,
                       capsize=3)
        
        ax.axvline(0.90, color='black', linestyle='--', linewidth=2, label='Target (90%)')
        ax.axvline(0.88, color='gray', linestyle=':', linewidth=1.5, label='Tolerance (88%)')
        
        ax.set_xlabel('Coverage')
        ax.set_title(f'DGP: {dgp.upper()}', fontsize=12, fontweight='bold')
        ax.set_xlim(0.7, 1.0)
        
        if idx == 0:
            ax.legend(loc='lower right')
    
    plt.suptitle('Coverage by DGP Type', fontsize=14, fontweight='bold')
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    
    plt.savefig(f'{output_dir}/coverage_by_dgp.png', dpi=150, bbox_inches='tight')
    plt.savefig(f'{output_dir}/coverage_by_dgp.pdf', bbox_inches='tight')
    plt.close()


def plot_coverage_by_learner(df: pd.DataFrame, output_dir: str = '.'):
    """Plot coverage comparison across learners."""
    
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    
    learners = df['learner'].unique()
    
    for idx, learner in enumerate(learners):
        ax = axes[idx]
        subset = df[df['learner'] == learner]
        
        method_cov = subset.groupby('method')['coverage'].agg(['mean', 'std']).reset_index()
        method_cov = method_cov.sort_values('mean', ascending=True)
        
        colors = ['green' if m >= 0.88 else 'red' for m in method_cov['mean']]
        ax.barh(method_cov['method'], method_cov['mean'], 
               xerr=method_cov['std'], color=colors, alpha=0.7, capsize=3)
        
        ax.axvline(0.90, color='black', linestyle='--', linewidth=2)
        ax.set_xlabel('Coverage')
        ax.set_title(f'Learner: {learner}', fontsize=12, fontweight='bold')
        ax.set_xlim(0.7, 1.0)
    
    plt.suptitle('Coverage by Learner Type', fontsize=14, fontweight='bold')
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    
    plt.savefig(f'{output_dir}/coverage_by_learner.png', dpi=150, bbox_inches='tight')
    plt.savefig(f'{output_dir}/coverage_by_learner.pdf', bbox_inches='tight')
    plt.close()


def plot_coverage_width_tradeoff(df: pd.DataFrame, output_dir: str = '.'):
    """Plot coverage vs width trade-off."""
    
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # Aggregate
    summary = df.groupby(['method', 'learner']).agg({
        'coverage': 'mean',
        'mean_width': 'mean'
    }).reset_index()
    
    # Color by learner
    palette = sns.color_palette('colorblind', n_colors=summary['learner'].nunique())
    learner_colors = dict(zip(summary['learner'].unique(), palette))
    
    for learner in summary['learner'].unique():
        subset = summary[summary['learner'] == learner]
        ax.scatter(subset['mean_width'], subset['coverage'], 
                  label=learner, s=100, alpha=0.7,
                  c=[learner_colors[learner]])
        
        # Add method labels
        for _, row in subset.iterrows():
            ax.annotate(row['method'], (row['mean_width'], row['coverage']),
                       xytext=(5, 5), textcoords='offset points', fontsize=7, alpha=0.7)
    
    ax.axhline(0.90, color='red', linestyle='--', linewidth=2, label='Target Coverage')
    ax.set_xlabel('Mean Interval Width', fontsize=12)
    ax.set_ylabel('Coverage', fontsize=12)
    ax.set_title('Coverage vs Width Trade-off', fontsize=14, fontweight='bold')
    ax.legend(loc='lower right')
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/coverage_width_tradeoff.png', dpi=150, bbox_inches='tight')
    plt.savefig(f'{output_dir}/coverage_width_tradeoff.pdf', bbox_inches='tight')
    plt.close()


def plot_outcome_conditional_coverage(df: pd.DataFrame, output_dir: str = '.'):
    """Plot outcome-conditional coverage comparison."""
    
    # Filter to methods with outcome-conditional coverage
    df_sub = df.dropna(subset=['coverage_claims_0', 'coverage_claims_1'])
    
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    for idx, dgp in enumerate(df_sub['dgp_type'].unique()[:4]):
        ax = axes.flatten()[idx]
        subset = df_sub[df_sub['dgp_type'] == dgp]
        
        summary = subset.groupby('method').agg({
            'coverage_claims_0': 'mean',
            'coverage_claims_1': 'mean',
            'coverage_claims_2plus': 'mean'
        }).reset_index()
        
        x = np.arange(len(summary))
        width = 0.25
        
        ax.bar(x - width, summary['coverage_claims_0'], width, label='Claims=0', alpha=0.8)
        ax.bar(x, summary['coverage_claims_1'], width, label='Claims=1', alpha=0.8)
        ax.bar(x + width, summary['coverage_claims_2plus'], width, label='Claims≥2', alpha=0.8)
        
        ax.axhline(0.90, color='red', linestyle='--', linewidth=2)
        ax.set_xticks(x)
        ax.set_xticklabels(summary['method'], rotation=45, ha='right', fontsize=8)
        ax.set_ylabel('Coverage')
        ax.set_title(f'DGP: {dgp.upper()}', fontsize=12, fontweight='bold')
        ax.set_ylim(0.5, 1.05)
        ax.legend(loc='lower right', fontsize=8)
    
    plt.suptitle('Outcome-Conditional Coverage', fontsize=14, fontweight='bold')
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    
    plt.savefig(f'{output_dir}/outcome_conditional_coverage.png', dpi=150, bbox_inches='tight')
    plt.savefig(f'{output_dir}/outcome_conditional_coverage.pdf', bbox_inches='tight')
    plt.close()


def plot_zero_inflation_effect(df: pd.DataFrame, output_dir: str = '.'):
    """Plot effect of zero inflation on coverage."""
    
    # Filter to DGPs with zero inflation parameter
    df_zi = df[df['dgp_type'].isin(['zip', 'hurdle'])].copy()
    
    if len(df_zi) == 0:
        print("No zero-inflated DGP results found")
        return
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    for idx, dgp in enumerate(['zip', 'hurdle']):
        ax = axes[idx]
        subset = df_zi[df_zi['dgp_type'] == dgp]
        
        if len(subset) == 0:
            continue
        
        # Aggregate by zero inflation level
        zi_summary = subset.groupby(['zero_inflation', 'method'])['coverage'].mean().unstack()
        
        if len(zi_summary) > 0:
            zi_summary.plot(kind='line', marker='o', ax=ax, alpha=0.7)
            ax.axhline(0.90, color='red', linestyle='--', linewidth=2, label='Target')
            ax.set_xlabel('Zero Inflation Level')
            ax.set_ylabel('Coverage')
            ax.set_title(f'DGP: {dgp.upper()}', fontsize=12, fontweight='bold')
            ax.legend(loc='lower left', fontsize=8, ncol=2)
            ax.set_ylim(0.7, 1.0)
    
    plt.suptitle('Effect of Zero Inflation on Coverage', fontsize=14, fontweight='bold')
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    
    plt.savefig(f'{output_dir}/zero_inflation_effect.png', dpi=150, bbox_inches='tight')
    plt.savefig(f'{output_dir}/zero_inflation_effect.pdf', bbox_inches='tight')
    plt.close()


def plot_sample_size_effect(df: pd.DataFrame, output_dir: str = '.'):
    """Plot effect of sample size on coverage and width."""
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    # Coverage by sample size
    ax1 = axes[0]
    n_summary = df.groupby(['n_obs', 'method'])['coverage'].mean().unstack()
    n_summary.plot(kind='line', marker='o', ax=ax1, alpha=0.7)
    ax1.axhline(0.90, color='red', linestyle='--', linewidth=2)
    ax1.set_xlabel('Sample Size')
    ax1.set_ylabel('Coverage')
    ax1.set_title('Coverage by Sample Size', fontsize=12, fontweight='bold')
    ax1.legend(loc='lower right', fontsize=7, ncol=2)
    
    # Width by sample size
    ax2 = axes[1]
    w_summary = df.groupby(['n_obs', 'method'])['mean_width'].mean().unstack()
    w_summary.plot(kind='line', marker='o', ax=ax2, alpha=0.7)
    ax2.set_xlabel('Sample Size')
    ax2.set_ylabel('Mean Interval Width')
    ax2.set_title('Interval Width by Sample Size', fontsize=12, fontweight='bold')
    ax2.legend(loc='upper right', fontsize=7, ncol=2)
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/sample_size_effect.png', dpi=150, bbox_inches='tight')
    plt.savefig(f'{output_dir}/sample_size_effect.pdf', bbox_inches='tight')
    plt.close()


def plot_heatmap_coverage(df: pd.DataFrame, output_dir: str = '.'):
    """Create heatmap of coverage across methods and configurations."""
    
    # Aggregate
    pivot = df.pivot_table(
        values='coverage',
        index='method',
        columns=['dgp_type', 'learner'],
        aggfunc='mean'
    )
    
    fig, ax = plt.subplots(figsize=(16, 10))
    
    # Custom colormap: red < 0.88, yellow = 0.90, green > 0.92
    from matplotlib.colors import LinearSegmentedColormap
    colors = [(0.8, 0.2, 0.2), (1, 1, 0.4), (0.2, 0.8, 0.2)]
    cmap = LinearSegmentedColormap.from_list('coverage', colors)
    
    sns.heatmap(pivot, annot=True, fmt='.3f', cmap=cmap, 
                vmin=0.75, vmax=0.95, ax=ax,
                cbar_kws={'label': 'Coverage'})
    
    ax.set_title('Coverage Heatmap: Methods × (DGP, Learner)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Method')
    ax.set_xlabel('')
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/coverage_heatmap.png', dpi=150, bbox_inches='tight')
    plt.savefig(f'{output_dir}/coverage_heatmap.pdf', bbox_inches='tight')
    plt.close()


# =============================================================================
# LATEX TABLES
# =============================================================================

def generate_latex_table(df: pd.DataFrame, output_dir: str = '.'):
    """Generate publication-ready LaTeX tables."""
    
    # Main results table
    summary = df.groupby(['method']).agg({
        'coverage': ['mean', 'std'],
        'mean_width': ['mean', 'std'],
        'interval_score': ['mean', 'std'],
        'coverage_gap': ['mean', 'std']
    }).round(4)
    
    summary.columns = ['Cov_Mean', 'Cov_Std', 'Width_Mean', 'Width_Std',
                       'IS_Mean', 'IS_Std', 'Gap_Mean', 'Gap_Std']
    
    # Format for LaTeX
    def fmt_mean_std(mean, std):
        return f"{mean:.3f} ({std:.3f})"
    
    latex_df = pd.DataFrame({
        'Method': summary.index,
        'Coverage': [fmt_mean_std(m, s) for m, s in zip(summary['Cov_Mean'], summary['Cov_Std'])],
        'Width': [fmt_mean_std(m, s) for m, s in zip(summary['Width_Mean'], summary['Width_Std'])],
        'Interval Score': [fmt_mean_std(m, s) for m, s in zip(summary['IS_Mean'], summary['IS_Std'])],
        'Coverage Gap': [fmt_mean_std(m, s) for m, s in zip(summary['Gap_Mean'], summary['Gap_Std'])]
    })
    
    # Save
    latex_str = latex_df.to_latex(index=False, escape=False)
    
    with open(f'{output_dir}/results_table.tex', 'w') as f:
        f.write(latex_str)
    
    # Also save as CSV
    latex_df.to_csv(f'{output_dir}/results_table.csv', index=False)
    
    return latex_df


# =============================================================================
# MAIN ANALYSIS
# =============================================================================

def analyze_simulation_results(results_path: str, output_dir: str = 'analysis_output'):
    """
    Main function to analyze simulation results.
    
    Parameters:
    -----------
    results_path : str
        Path to the combined results file (pickle or CSV)
    output_dir : str
        Directory to save output figures and tables
    """
    
    # Create output directory
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    print("=" * 60)
    print("SIMULATION RESULTS ANALYSIS")
    print("=" * 60)
    
    # Load and preprocess
    print("\n1. Loading results...")
    df = load_results(results_path)
    df = preprocess_results(df)
    
    print(f"   Loaded {len(df)} rows")
    print(f"   DGP types: {df['dgp_type'].unique()}")
    print(f"   Learners: {df['learner'].unique()}")
    print(f"   Methods: {df['method'].nunique()}")
    print(f"   Repetitions: {df['repetition'].nunique()}")
    
    # Summary statistics
    print("\n2. Computing summary statistics...")
    summary = compute_summary_stats(df)
    summary.to_csv(f'{output_dir}/summary_statistics.csv', index=False)
    print(f"   Saved to {output_dir}/summary_statistics.csv")
    
    # Method rankings
    print("\n3. Computing method rankings...")
    rankings = compute_method_rankings(df)
    rankings.to_csv(f'{output_dir}/method_rankings.csv', index=False)
    
    # Best methods by criteria
    print("\n   Best methods by criteria:")
    for criterion in ['rank_coverage', 'rank_width', 'rank_is', 'rank_gap', 'rank_combined']:
        best = rankings.groupby('method')[criterion].mean().idxmin()
        print(f"   - {criterion}: {best}")
    
    # Generate visualizations
    print("\n4. Generating visualizations...")
    
    plot_coverage_by_dgp(df, output_dir)
    print("   - coverage_by_dgp.png")
    
    plot_coverage_by_learner(df, output_dir)
    print("   - coverage_by_learner.png")
    
    plot_coverage_width_tradeoff(df, output_dir)
    print("   - coverage_width_tradeoff.png")
    
    plot_outcome_conditional_coverage(df, output_dir)
    print("   - outcome_conditional_coverage.png")
    
    plot_zero_inflation_effect(df, output_dir)
    print("   - zero_inflation_effect.png")
    
    plot_sample_size_effect(df, output_dir)
    print("   - sample_size_effect.png")
    
    plot_heatmap_coverage(df, output_dir)
    print("   - coverage_heatmap.png")
    
    # Generate LaTeX tables
    print("\n5. Generating LaTeX tables...")
    latex_table = generate_latex_table(df, output_dir)
    print("   - results_table.tex")
    print("   - results_table.csv")
    
    # Print summary table
    print("\n" + "=" * 60)
    print("MAIN RESULTS SUMMARY")
    print("=" * 60)
    print(latex_table.to_string(index=False))
    
    # Key findings
    print("\n" + "=" * 60)
    print("KEY FINDINGS")
    print("=" * 60)
    
    # Coverage statistics
    valid_rate = (df['coverage'] >= 0.88).mean() * 100
    print(f"\n1. Valid Coverage Rate (≥88%): {valid_rate:.1f}%")
    
    # Best overall method
    method_summary = df.groupby('method').agg({
        'coverage': 'mean',
        'mean_width': 'mean',
        'coverage_gap': 'mean'
    })
    
    # Filter valid methods
    valid_methods = method_summary[method_summary['coverage'] >= 0.88]
    if len(valid_methods) > 0:
        best_by_width = valid_methods['mean_width'].idxmin()
        best_by_gap = valid_methods['coverage_gap'].idxmin()
        print(f"\n2. Best Valid Method (narrowest): {best_by_width}")
        print(f"3. Best Valid Method (smallest gap): {best_by_gap}")
    
    # By DGP
    print("\n4. Coverage by DGP (mean):")
    dgp_summary = df.groupby('dgp_type')['coverage'].mean()
    for dgp, cov in dgp_summary.items():
        print(f"   - {dgp}: {cov:.4f}")
    
    # By Learner
    print("\n5. Coverage by Learner (mean):")
    learner_summary = df.groupby('learner')['coverage'].mean()
    for learner, cov in learner_summary.items():
        print(f"   - {learner}: {cov:.4f}")
    
    print("\n" + "=" * 60)
    print(f"Analysis complete. Results saved to: {output_dir}/")
    print("=" * 60)
    
    return df, summary, rankings


# =============================================================================
# COMMAND LINE INTERFACE
# =============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Analyze CP simulation results')
    parser.add_argument('results_path', type=str, help='Path to results file')
    parser.add_argument('--output', '-o', type=str, default='analysis_output',
                       help='Output directory')
    
    args = parser.parse_args()
    
    analyze_simulation_results(args.results_path, args.output)





"""
Enhanced analysis with insurance-specific metrics and visualizations
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from typing import Dict, List, Optional
import warnings
warnings.filterwarnings('ignore')

# Set style
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("colorblind")

def load_and_combine_results(results_path: str) -> pd.DataFrame:
    """Load and combine results from a file or directory of parquet files"""
    results_path = Path(results_path)
    
    # If it's a single file, load it directly
    if results_path.is_file():
        print(f"Loading single file: {results_path}")
        df = pd.read_parquet(results_path)
        print(f"Loaded {len(df)} rows")
        return df
    
    # If it's a directory, glob for parquet files
    if results_path.is_dir():
        all_files = list(results_path.glob("**/*.parquet"))
        print(f"Found {len(all_files)} parquet files in {results_path}")
        dfs = []
        for file in all_files:
            try:
                df = pd.read_parquet(file)
                dfs.append(df)
            except Exception as e:
                print(f"Error reading {file}: {e}")
        
        if dfs:
            combined = pd.concat(dfs, ignore_index=True)
            print(f"Loaded {len(combined)} rows from {len(dfs)} files")
            return combined
    
    raise ValueError(f"No results found at: {results_path}")

def compute_comprehensive_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """Compute comprehensive evaluation metrics"""
    
    # Group by key dimensions
    group_cols = ['dgp_type', 'learner', 'method', 'n_obs', 'dim_x', 
                  'zero_inflation', 'overdispersion', 'correlation_strength']
    
    summary = df.groupby(group_cols).agg({
        'coverage': ['mean', 'std', 'count'],
        'mean_width': ['mean', 'std'],
        'interval_score': ['mean', 'std'],
        'coverage_gap': ['mean', 'std'],
        'risk_differentiation': ['mean', 'std'],
        'pct_informative': ['mean', 'std'],
        'var_95_coverage': ['mean', 'std'],
        'var_99_coverage': ['mean', 'std'],
        'tail_coverage': ['mean', 'std'],
        'calibration_range': ['mean', 'std'],
    }).round(4)
    
    # Flatten column names
    summary.columns = ['_'.join(col).strip() for col in summary.columns.values]
    summary = summary.reset_index()
    
    # Add validity indicator (coverage >= 1-alpha - tolerance)
    target = 0.9
    tolerance = 0.02
    summary['is_valid'] = summary['coverage_mean'] >= (target - tolerance)
    
    return summary

def create_insurance_specific_plots(df: pd.DataFrame, output_dir: str):
    """Create insurance-specific visualizations"""
    
    # 1. Risk Differentiation Plot
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    # Plot by DGP type
    for idx, dgp in enumerate(df['dgp_type'].unique()[:4]):
        ax = axes.flatten()[idx]
        subset = df[df['dgp_type'] == dgp]
        
        # Scatter: coverage vs risk differentiation
        scatter = ax.scatter(
            subset['coverage_mean'], 
            subset['risk_differentiation_mean'],
            c=subset['mean_width_mean'],
            s=100,
            alpha=0.7,
            cmap='viridis'
        )
        
        ax.axvline(0.9, color='red', linestyle='--', alpha=0.5)
        ax.axhline(0, color='gray', linestyle=':', alpha=0.5)
        
        ax.set_xlabel('Coverage')
        ax.set_ylabel('Risk Differentiation (Correlation)')
        ax.set_title(f'DGP: {dgp.upper()}')
        
        # Colorbar for width
        plt.colorbar(scatter, ax=ax, label='Mean Width')
    
    plt.suptitle('Coverage vs Risk Differentiation by DGP', fontsize=14, fontweight='bold')
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig(f'{output_dir}/risk_differentiation.png', dpi=150, bbox_inches='tight')
    
    # 2. Tail Risk Coverage
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    
    metrics = ['var_95_coverage_mean', 'var_99_coverage_mean', 'tail_coverage_mean']
    titles = ['VaR 95% Coverage', 'VaR 99% Coverage', 'Tail (90%+) Coverage']
    
    for idx, (metric, title) in enumerate(zip(metrics, titles)):
        ax = axes[idx]
        
        # Group by method
        method_summary = df.groupby('method')[metric].mean().sort_values()
        
        colors = ['green' if v >= 0.85 else 'orange' if v >= 0.8 else 'red' 
                 for v in method_summary.values]
        
        ax.barh(method_summary.index, method_summary.values, color=colors, alpha=0.7)
        ax.axvline(0.9, color='red', linestyle='--', linewidth=2)
        ax.set_xlabel('Coverage')
        ax.set_title(title)
        ax.set_xlim(0.5, 1.0)
    
    plt.suptitle('Tail Risk Coverage by Method', fontsize=14, fontweight='bold')
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig(f'{output_dir}/tail_risk_coverage.png', dpi=150, bbox_inches='tight')
    
    # 3. Informativeness vs Coverage
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # Color by method type
    method_types = {
        'Parametric': ['Parametric_Poisson', 'Parametric_NegBin'],
        'Bootstrap': ['Bootstrap_Poisson'],
        'ICP': ['ICP_poisson_deviance', 'ICP_za_relative'],
        'Mondrian': ['Mondrian_Poisson'],
        'Two-Stage': ['Two_Stage_CP', 'Two_Stage_Exact_CP', 'Two_Stage_Bonf_CP'],
        'Binary': ['Binary_CP_Marginal', 'Binary_CP_Mondrian']
    }
    
    colors = sns.color_palette('colorblind', n_colors=len(method_types))
    
    for (method_type, methods), color in zip(method_types.items(), colors):
        subset = df[df['method'].isin(methods)]
        if len(subset) > 0:
            ax.scatter(
                subset['pct_informative_mean'],
                subset['coverage_mean'],
                label=method_type,
                s=100,
                alpha=0.7,
                color=color,
                edgecolors='black'
            )
    
    ax.axhline(0.9, color='red', linestyle='--', linewidth=2, label='Target Coverage')
    ax.set_xlabel('% Informative Intervals')
    ax.set_ylabel('Coverage')
    ax.set_title('Informativeness vs Coverage Trade-off')
    ax.legend(loc='lower right')
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/informativeness_vs_coverage.png', dpi=150, bbox_inches='tight')