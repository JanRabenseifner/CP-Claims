#!/bin/bash
#SBATCH --partition=std
#SBATCH --ntasks=96
#SBATCH --cpus-per-task=1
#SBATCH --time=12:00:00
#SBATCH --job-name=cp_claims
#SBATCH --output=%x-%j.out
#SBATCH --error=%x-%j.err

set -e
set -x

source /sw/batch/init.sh
module unload env
module load env/gcc-13.2.0_openmpi-4.1.6
source /usw/baz9569/anaconda3/bin/activate shapley_doubleml_2

export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

PROJECT_DIR=${PROJECT_DIR:-$PWD}
RUN_NAME=${RUN_NAME:-main}
RESULTS_ROOT=${RESULTS_ROOT:-${PROJECT_DIR}/results}
RESULTS_DIR=${RESULTS_DIR:-${RESULTS_ROOT}/${RUN_NAME}_${SLURM_JOB_ID}}
export PYTHONPATH="${PROJECT_DIR}/src:${PYTHONPATH}"
export RESULTS_DIR

mkdir -p "$RESULTS_DIR"

cd "$PROJECT_DIR"

echo "=============================================="
echo "COUNT DATA CP SIMULATION"
echo "=============================================="
echo "Job ID: ${SLURM_JOB_ID}"
echo "Results dir: ${RESULTS_DIR}"
echo "Start time: $(date)"
echo "=============================================="

mpirun python scripts/run_simulation.py \
    --output-dir "$RESULTS_DIR" \
    --repetitions 96 \
    --dgcp-methods hybrid,full,exact \
    --min-group-sizes 100,200

python scripts/combine_results.py "$RESULTS_DIR" --output "$RESULTS_DIR/results_combined.parquet"

echo "=============================================="
echo "Simulation completed at: $(date)"
echo "=============================================="