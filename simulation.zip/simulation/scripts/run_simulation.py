from __future__ import annotations

import argparse
import itertools
import sys
import time
import warnings
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OrdinalEncoder

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = REPO_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from cp_claims.utils_benchmarks import run_parametric_benchmarks
from cp_claims.utils_dgcp import two_stage_dgcp_cp
from cp_claims.utils_dgps import EnhancedCountDGP, split_data, summarize_dgp_output
from cp_claims.utils_eval import interval_score
from cp_claims.utils_pinterval import (
    binary_classification_cp,
    discrete_conformal_poisson,
    mondrian_conformal_poisson,
)
from cp_claims.utils_two_stage import (
    two_stage_balanced_v2_cp,
    two_stage_calibrated_cp,
    two_stage_direct_cp,
    two_stage_empirical_cp,
    two_stage_exact_cp,
    two_stage_weighted_cp,
)

warnings.filterwarnings("ignore")

try:
    from mpi4py import MPI

    COMM = MPI.COMM_WORLD
    RANK = COMM.Get_rank()
    SIZE = COMM.Get_size()
except ImportError:
    COMM = None
    RANK = 0
    SIZE = 1

try:
    from lightgbm import LGBMRegressor

    LGBM_AVAILABLE = True
except ImportError:
    LGBM_AVAILABLE = False


def parse_int_list(value: str) -> list[int]:
    return [int(item) for item in value.split(",") if item]


def parse_float_list(value: str) -> list[float]:
    return [float(item) for item in value.split(",") if item]


def parse_str_list(value: str) -> list[str]:
    return [item for item in value.split(",") if item]


def parse_bool_list(value: str) -> list[bool]:
    mapping = {"true": True, "false": False}
    return [mapping[item.lower()] for item in value.split(",") if item]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="MPI simulation driver for the count-data conformal prediction study")
    parser.add_argument("--output-dir", default="results/run")
    parser.add_argument("--repetitions", type=int, default=96)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--alpha", type=float, default=0.1)
    parser.add_argument("--n-obs", default="1000,2000,4000,6000,10000")
    parser.add_argument("--dim-x", default="10,20,50")
    parser.add_argument("--dgp-types", default="poisson,zip,negbin,hurdle")
    parser.add_argument("--correlation-types", default="toeplitz")
    parser.add_argument("--correlation-strength", default="0.0,0.3,0.5")
    parser.add_argument("--categorical-ratio", default="0.1,0.3,0.5")
    parser.add_argument("--interaction-effects", default="false,true")
    parser.add_argument("--spatial-effects", default="false,true")
    parser.add_argument("--exposure-types", default="realistic")
    parser.add_argument("--learners", default="Poisson_GLM,LightGBM,RandomForest")
    parser.add_argument("--dgcp-methods", default="hybrid,full,exact")
    parser.add_argument("--min-group-sizes", default="100,200")
    parser.add_argument("--skip-standard", action="store_true")
    parser.add_argument("--include-two-stage-exact", action="store_true")
    return parser


def fit_poisson_glm(train_data: pd.DataFrame, valid_vars: list[str]):
    x_train = pd.get_dummies(train_data[valid_vars], drop_first=True, dtype=float)
    x_train = sm.add_constant(x_train)
    model = sm.GLM(
        train_data["Claims"],
        x_train,
        family=sm.families.Poisson(),
        exposure=train_data["Exposure"],
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            fitted = model.fit(maxiter=100)
        except Exception:
            fitted = model.fit_regularized(alpha=0.01)

    def predict(data_subset: pd.DataFrame) -> np.ndarray:
        x = pd.get_dummies(data_subset[valid_vars], drop_first=True, dtype=float)
        x = sm.add_constant(x)
        for column in fitted.model.exog_names:
            if column not in x.columns:
                x[column] = 0
        x = x[fitted.model.exog_names]
        return np.clip(fitted.predict(x) * data_subset["Exposure"].values, 1e-6, 100)

    return predict


def fit_lgbm(train_data: pd.DataFrame, valid_vars: list[str]):
    if not LGBM_AVAILABLE:
        raise ImportError("LightGBM not available")

    num_cols = [
        column
        for column in valid_vars
        if train_data[column].dtype.name != "category" and np.issubdtype(train_data[column].dtype, np.number)
    ]
    cat_cols = [column for column in valid_vars if column not in num_cols]
    transformers: list[tuple[str, object, list[str]]] = []
    if num_cols:
        transformers.append(("num", "passthrough", num_cols))
    if cat_cols:
        transformers.append(("cat", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1), cat_cols))
    preprocessor = ColumnTransformer(transformers=transformers, verbose_feature_names_out=False).set_output(transform="pandas")
    x_train = preprocessor.fit_transform(train_data[valid_vars])
    y_train = train_data["Claims"] / train_data["Exposure"]
    model = LGBMRegressor(
        objective="poisson",
        learning_rate=0.05,
        num_leaves=31,
        reg_lambda=2.0,
        reg_alpha=2.0,
        n_estimators=200,
        random_state=42,
        verbosity=-1,
    )
    model.fit(x_train, y_train, sample_weight=train_data["Exposure"])

    def predict(data_subset: pd.DataFrame) -> np.ndarray:
        x = preprocessor.transform(data_subset[valid_vars])
        return np.clip(model.predict(x) * data_subset["Exposure"].values, 1e-6, 100)

    return predict


def fit_random_forest(train_data: pd.DataFrame, valid_vars: list[str]):
    num_cols = [
        column
        for column in valid_vars
        if train_data[column].dtype.name != "category" and np.issubdtype(train_data[column].dtype, np.number)
    ]
    cat_cols = [column for column in valid_vars if column not in num_cols]
    transformers: list[tuple[str, object, list[str]]] = []
    if num_cols:
        transformers.append(("num", "passthrough", num_cols))
    if cat_cols:
        transformers.append(("cat", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1), cat_cols))
    preprocessor = ColumnTransformer(transformers=transformers, verbose_feature_names_out=False).set_output(transform="pandas")
    x_train = preprocessor.fit_transform(train_data[valid_vars])
    y_train = train_data["Claims"] / train_data["Exposure"]
    model = RandomForestRegressor(
        criterion="poisson",
        n_estimators=100,
        max_features="sqrt",
        max_depth=10,
        min_samples_leaf=20,
        random_state=42,
        n_jobs=1,
    )
    model.fit(x_train, y_train, sample_weight=train_data["Exposure"])

    def predict(data_subset: pd.DataFrame) -> np.ndarray:
        x = preprocessor.transform(data_subset[valid_vars])
        return np.clip(model.predict(x) * data_subset["Exposure"].values, 1e-6, 100)

    return predict


LEARNER_FUNCTIONS = {
    "Poisson_GLM": fit_poisson_glm,
    "LightGBM": fit_lgbm,
    "RandomForest": fit_random_forest,
}


def generate_meaningful_clusters(df: pd.DataFrame, n_clusters: int = 5) -> np.ndarray:
    cluster_features: list[str] = []
    for column in df.columns:
        if column.startswith("Region"):
            cluster_features.append(column)
        elif column.startswith("Coverage"):
            cluster_features.append(column)
        elif "age" in column.lower():
            cluster_features.append(column)
    if not cluster_features:
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            cluster_features = [numeric_cols[0]]
        else:
            return np.ones(len(df))
    cluster_data = pd.get_dummies(df[cluster_features], drop_first=True).values
    n_clusters = min(n_clusters, len(cluster_data) // 10, 10)
    if len(cluster_data) >= n_clusters and n_clusters > 0:
        return KMeans(n_clusters=n_clusters, random_state=42, n_init=10).fit_predict(cluster_data) + 1
    return np.ones(len(df))


def compute_metrics(y_true: np.ndarray, lower: np.ndarray, upper: np.ndarray, pred_mu: np.ndarray, alpha: float) -> dict[str, float]:
    covered = (y_true >= lower) & (y_true <= upper)
    widths = upper - lower
    metrics: dict[str, float] = {
        "coverage": float(np.mean(covered)),
        "mean_width": float(np.mean(widths)),
        "median_width": float(np.median(widths)),
        "width_std": float(np.std(widths)),
        "interval_score": float(interval_score(y_true, lower, upper, alpha)),
        "pct_singleton": float(100 * np.mean(widths == 0)),
    }
    y0_mask = y_true == 0
    y1_mask = y_true == 1
    y2plus_mask = y_true >= 2
    metrics["n_y0"] = int(y0_mask.sum())
    metrics["n_y1"] = int(y1_mask.sum())
    metrics["n_y2plus"] = int(y2plus_mask.sum())
    min_obs = 5
    metrics["coverage_y0"] = float(np.mean(covered[y0_mask])) if y0_mask.sum() >= min_obs else np.nan
    metrics["coverage_y1"] = float(np.mean(covered[y1_mask])) if y1_mask.sum() >= min_obs else np.nan
    metrics["coverage_y2plus"] = float(np.mean(covered[y2plus_mask])) if y2plus_mask.sum() >= min_obs else np.nan
    metrics["coverage_gap"] = abs(metrics["coverage_y0"] - metrics["coverage_y1"]) if y0_mask.sum() >= min_obs and y1_mask.sum() >= min_obs else np.nan
    bin_edges = [(1, 5), (6, 10), (11, 20), (21, 50), (51, np.inf)]
    max_y = int(np.max(y_true)) if len(y_true) > 0 else 0
    for low, high in bin_edges:
        if max_y < low:
            continue
        if np.isinf(high):
            mask = y_true >= low
            name = f"coverage_y{int(low)}plus"
            count_name = f"n_y{int(low)}_plus"
        else:
            mask = (y_true >= low) & (y_true <= high)
            name = f"coverage_y{int(low)}_{int(high)}"
            count_name = f"n_y{int(low)}_{int(high)}"
        if mask.any():
            metrics[name] = float(np.mean(covered[mask]))
            metrics[count_name] = int(mask.sum())
    if len(pred_mu) > 1 and np.std(widths) > 0:
        metrics["risk_differentiation"] = float(np.corrcoef(pred_mu, widths)[0, 1])
    else:
        metrics["risk_differentiation"] = np.nan
    for level in [0.95, 0.99]:
        threshold = np.percentile(y_true, level * 100)
        mask = y_true >= threshold
        if mask.any():
            metrics[f"var_{int(level * 100)}_coverage"] = float(np.mean(covered[mask]))
    tail_mask = y_true >= np.percentile(y_true, 90)
    if tail_mask.any():
        metrics["tail_mean_width"] = float(np.mean(widths[tail_mask]))
        metrics["tail_coverage"] = float(np.mean(covered[tail_mask]))
    informative = (lower > 0) | (upper < np.inf)
    metrics["pct_informative"] = float(100 * np.mean(informative))
    risk_deciles = pd.qcut(pred_mu, q=10, duplicates="drop", labels=False)
    calibration_by_risk = []
    for decile in np.unique(risk_deciles):
        mask = risk_deciles == decile
        if mask.any():
            calibration_by_risk.append(np.mean(covered[mask]))
    metrics["calibration_range"] = float(np.max(calibration_by_risk) - np.min(calibration_by_risk)) if calibration_by_risk else np.nan
    return metrics


def build_configs(args: argparse.Namespace) -> list[dict[str, Any]]:
    param_grid = {
        "dgp_type": parse_str_list(args.dgp_types),
        "n_obs": parse_int_list(args.n_obs),
        "dim_x": parse_int_list(args.dim_x),
        "correlation_type": parse_str_list(args.correlation_types),
        "correlation_strength": parse_float_list(args.correlation_strength),
        "categorical_ratio": parse_float_list(args.categorical_ratio),
        "exposure_type": parse_str_list(args.exposure_types),
        "interaction_effects": parse_bool_list(args.interaction_effects),
        "spatial_effects": parse_bool_list(args.spatial_effects),
    }
    configs: list[dict[str, Any]] = []
    keys, values = zip(*param_grid.items())
    for index, combination in enumerate(itertools.product(*values)):
        config = dict(zip(keys, combination))
        rng = np.random.default_rng(args.seed + index)
        config["zero_inflation"] = float(rng.choice([0.0, 0.1, 0.3, 0.5])) if config["dgp_type"] in {"zip", "hurdle"} else 0.0
        config["overdispersion"] = float(rng.choice([2.0, 3.0, 4.0, 5.0])) if config["dgp_type"] == "negbin" else 1.0
        configs.append(config)
    return configs


def run_single_configuration(config: dict[str, Any], args: argparse.Namespace, learners: list[str], dgcp_methods: list[str], min_group_sizes: list[int]) -> list[dict[str, Any]]:
    dgp = EnhancedCountDGP(seed=config["seed"])
    df = dgp.generate_covariates(
        n_obs=config["n_obs"],
        dim_x=config["dim_x"],
        correlation_type=config["correlation_type"],
        categorical_ratio=config["categorical_ratio"],
        correlation_strength=config["correlation_strength"],
    )
    exposure = dgp.generate_exposure(n_obs=config["n_obs"], exposure_type=config["exposure_type"])
    y, mu_true, _ = dgp.generate_claims(
        df=df,
        exposure=exposure,
        dgp_type=config["dgp_type"],
        zero_inflation=config["zero_inflation"],
        overdispersion=config["overdispersion"],
        interaction_effects=config["interaction_effects"],
        spatial_effects=config["spatial_effects"],
    )
    df["Claims"] = y
    df["Exposure"] = exposure
    df["pred_mu_true"] = mu_true
    splits = split_data({"df": df, "params": config}, train_frac=0.6, calib_frac=0.2, seed=config["seed"])
    train_data = splits["train"]
    calib_data = splits["calib"]
    test_data = splits["test"]
    train_data["Cluster"] = generate_meaningful_clusters(train_data)
    calib_data["Cluster"] = generate_meaningful_clusters(calib_data)
    test_data["Cluster"] = generate_meaningful_clusters(test_data)
    valid_vars = [column for column in train_data.columns if column not in {"Claims", "Exposure", "pred_mu_true", "pi_true", "Cluster"}]
    results: list[dict[str, Any]] = []
    dgp_summary = summarize_dgp_output({"y": y, "mu": mu_true})

    for learner_name in learners:
        if learner_name == "LightGBM" and not LGBM_AVAILABLE:
            continue
        fit_learner = LEARNER_FUNCTIONS[learner_name]
        try:
            predict_func = fit_learner(train_data, valid_vars)
            calib_copy = calib_data.copy()
            test_copy = test_data.copy()
            calib_copy["pred_mu"] = predict_func(calib_copy)
            test_copy["pred_mu"] = predict_func(test_copy)
            pred_mu = test_copy["pred_mu"].values
            calib_mu = calib_copy["pred_mu"].values
            calib_y = calib_copy["Claims"].values
            test_y = test_copy["Claims"].values
            calib_cluster = calib_copy["Cluster"].values
            test_cluster = test_copy["Cluster"].values
            cp_results: dict[str, Any] = {}

            if not args.skip_standard:
                if learner_name == "Poisson_GLM":
                    try:
                        benchmark_vars = [column for column in train_data.columns if column not in ["Claims", "Exposure", "Cluster", "pred_mu", "pred_mu_true"]]
                        benchmarks = run_parametric_benchmarks(train_data, calib_data, test_data, benchmark_vars, args.alpha)
                        cp_results.update({key: value for key, value in benchmarks.items() if not key.startswith("_")})
                    except Exception:
                        cp_results["Poisson_Normal"] = None
                        cp_results["Poisson_Bootstrap"] = None
                        cp_results["NB_Chebyshev"] = None
                        cp_results["NB_Bootstrap"] = None
                        cp_results["NB_Plugin"] = None
                try:
                    cp_results["ICP_poisson_deviance"] = discrete_conformal_poisson(pred_mu, calib_mu, calib_y, args.alpha, "poisson_deviance")
                except Exception:
                    cp_results["ICP_poisson_deviance"] = None
                try:
                    cp_results["ICP_za_relative"] = discrete_conformal_poisson(pred_mu, calib_mu, calib_y, args.alpha, "za_relative")
                except Exception:
                    cp_results["ICP_za_relative"] = None
                try:
                    cp_results["Mondrian_Poisson"] = mondrian_conformal_poisson(pred_mu, test_cluster, calib_mu, calib_y, calib_cluster, args.alpha, "poisson_deviance")
                except Exception:
                    cp_results["Mondrian_Poisson"] = None
                for method_name, function in [
                    ("Two_Stage_Balanced_V2_CP", two_stage_balanced_v2_cp),
                    ("Two_Stage_Direct_CP", two_stage_direct_cp),
                    ("Two_Stage_Empirical_CP", two_stage_empirical_cp),
                    ("Two_Stage_Weighted_CP", two_stage_weighted_cp),
                    ("Two_Stage_Calibrated_CP", two_stage_calibrated_cp),
                ]:
                    try:
                        cp_results[method_name] = function(pred_mu, calib_mu, calib_y, args.alpha)
                    except Exception:
                        cp_results[method_name] = None
                if args.include_two_stage_exact:
                    try:
                        cp_results["Two_Stage_Exact_CP"] = two_stage_exact_cp(pred_mu, calib_mu, calib_y, args.alpha, min_group_size=min(min_group_sizes))
                    except Exception:
                        cp_results["Two_Stage_Exact_CP"] = None
                calib_y_binary = (calib_y > 0).astype(int)
                calib_probs = np.column_stack([np.exp(-calib_mu), 1 - np.exp(-calib_mu)])
                test_probs = np.column_stack([np.exp(-pred_mu), 1 - np.exp(-pred_mu)])
                try:
                    cp_results["Binary_CP_Marginal"] = binary_classification_cp(test_probs, calib_probs, calib_y_binary, args.alpha, mondrian=False)
                except Exception:
                    cp_results["Binary_CP_Marginal"] = None
                try:
                    cp_results["Binary_CP_Mondrian"] = binary_classification_cp(test_probs, calib_probs, calib_y_binary, args.alpha, mondrian=True)
                except Exception:
                    cp_results["Binary_CP_Mondrian"] = None

            for dgcp_method in dgcp_methods:
                for min_group_size in min_group_sizes:
                    method_name = f"DGCP_{dgcp_method.title()}_m{min_group_size}"
                    try:
                        cp_results[method_name] = (
                            two_stage_dgcp_cp(
                                pred_mu=pred_mu,
                                calib_mu=calib_mu,
                                calib_y=calib_y,
                                alpha=args.alpha,
                                ncs_type="poisson_deviance",
                                min_group_size=min_group_size,
                                method=dgcp_method,
                                verbose=False,
                            ),
                            min_group_size,
                        )
                    except Exception:
                        cp_results[method_name] = (None, min_group_size)

            for method_name, result in cp_results.items():
                row: dict[str, Any] = {
                    "method": method_name,
                    "learner": learner_name,
                    **config,
                    "pct_zeros_data": dgp_summary["pct_zeros"],
                    "mean_y_data": dgp_summary["mean_y"],
                    "var_y_data": dgp_summary["var_y"],
                    "dispersion_ratio": dgp_summary["dispersion_ratio"],
                }
                min_group_size_value = np.nan
                if method_name.startswith("DGCP_"):
                    result, min_group_size_value = result
                row["min_group_size"] = min_group_size_value
                if result is None:
                    row["error"] = "Method failed"
                    results.append(row)
                    continue
                if method_name in {"Binary_CP_Marginal", "Binary_CP_Mondrian"}:
                    binary_truth = (test_y > 0).astype(int)
                    covered = np.array([truth in prediction_set for truth, prediction_set in zip(binary_truth, result)])
                    set_sizes = np.array([len(prediction_set) for prediction_set in result])
                    lower = np.zeros(len(test_y))
                    upper = np.zeros(len(test_y))
                    for index, (prediction_set, mu_value) in enumerate(zip(result, pred_mu)):
                        if 0 in prediction_set and 1 in prediction_set:
                            lower[index] = 0
                            upper[index] = max(stats.poisson.ppf(1 - args.alpha / 2, mu_value), 1)
                        elif 0 in prediction_set:
                            lower[index] = 0
                            upper[index] = 0
                        else:
                            lower[index] = 1
                            upper[index] = max(stats.poisson.ppf(1 - args.alpha / 2, mu_value), 1)
                    metrics = compute_metrics(test_y, lower, upper, pred_mu, args.alpha)
                    row.update(metrics)
                    row["coverage"] = float(np.mean(covered))
                    row["mean_width"] = float(np.mean(set_sizes))
                    row["median_width"] = float(np.median(set_sizes))
                    row["coverage_claims_0"] = float(np.mean(covered[test_y == 0])) if (test_y == 0).sum() > 0 else np.nan
                    row["coverage_claims_1"] = float(np.mean(covered[test_y >= 1])) if (test_y >= 1).sum() > 0 else np.nan
                    row["pct_singleton"] = float(100 * np.mean(set_sizes == 1))
                else:
                    lower = result["lower"].values if "lower" in result.columns else result["lower_bound"].values
                    upper = result["upper"].values if "upper" in result.columns else result["upper_bound"].values
                    metrics = compute_metrics(test_y, lower, upper, pred_mu, args.alpha)
                    covered = (test_y >= lower) & (test_y <= upper)
                    row.update(metrics)
                    row["coverage_claims_0"] = float(np.mean(covered[test_y == 0])) if (test_y == 0).sum() > 0 else np.nan
                    row["coverage_claims_1"] = float(np.mean(covered[test_y == 1])) if (test_y == 1).sum() > 0 else np.nan
                    row["coverage_claims_2plus"] = float(np.mean(covered[test_y >= 2])) if (test_y >= 2).sum() > 0 else np.nan
                results.append(row)
        except Exception as exc:
            results.append({"learner": learner_name, "error": str(exc), **config})
    return results


def main() -> None:
    args = build_parser().parse_args()
    learners = parse_str_list(args.learners)
    dgcp_methods = parse_str_list(args.dgcp_methods)
    min_group_sizes = parse_int_list(args.min_group_sizes)
    base_configs = build_configs(args)

    reps_per_process = args.repetitions // SIZE
    extra_reps = args.repetitions % SIZE
    if RANK < extra_reps:
        reps_per_process += 1
        start_rep = RANK * reps_per_process
    else:
        start_rep = RANK * reps_per_process + extra_reps
    end_rep = start_rep + reps_per_process

    if RANK == 0:
        print("=" * 80)
        print("COUNT DATA CONFORMAL PREDICTION SIMULATION")
        print("=" * 80)
        print(f"MPI Processes: {SIZE}")
        print(f"Total Repetitions: {args.repetitions}")
        print(f"Configurations per repetition: {len(base_configs)}")
        print(f"DGCP methods: {dgcp_methods}")
        print(f"Min group sizes: {min_group_sizes}")
        print("=" * 80)

    start_time = time.time()
    results: list[dict[str, Any]] = []
    for rep in range(start_rep, end_rep):
        for config_index, base_config in enumerate(base_configs):
            sim_config = base_config.copy()
            sim_config["seed"] = args.seed + rep * 1000 + config_index
            sim_config["repetition"] = rep
            try:
                results.extend(run_single_configuration(sim_config, args, learners, dgcp_methods, min_group_sizes))
            except Exception as exc:
                results.append({"error": str(exc), **sim_config})

    output_dir = Path(args.output_dir) / f"rank_{RANK:03d}"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / f"results_{RANK:03d}.parquet"
    pd.DataFrame(results).to_parquet(output_file, index=False)
    print(f"Rank {RANK}: Saved {len(results)} results to {output_file}")

    if COMM is not None:
        COMM.Barrier()

    print(f"Rank {RANK}: Completed in {time.time() - start_time:.1f} seconds")


if __name__ == "__main__":
    main()