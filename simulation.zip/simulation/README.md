# CP-Claims

This repository contains a cleaned, reproducible version of the count-data conformal prediction simulation study.

The structure is split into three layers:

- `src/cp_claims`: reusable package code for simulation, DGCP utilities, evaluation utilities, and analysis helpers
- `scripts`: command-line entrypoints for running simulations, combining partial outputs, and generating evaluation artifacts
- `notebooks`: a lightweight notebook for interactive inspection of combined results

## Installation

From the repository root:

```powershell
cd code
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -U pip
pip install -e .
```

Optional extras:

```powershell
pip install -e .[lightgbm]
pip install -e .[hpc]
```

## Running the simulation

The repository uses one MPI Python driver and one SLURM shell script.

Run locally from the repository root:

```powershell
cd code
python scripts/run_simulation.py --output-dir results/local_test --repetitions 2
```

Run on the HPC cluster with the same `mpirun python ...` pattern as the original project:

```bash
cd code
sbatch scripts/run_simulation_hpc.sh
```

The shell script runs one Python driver for the full method set and then combines the rank-level parquet files into `results_combined.parquet` inside the job output directory.

If you need a different cluster location, set `PROJECT_DIR`, `RESULTS_ROOT`, `RUN_NAME`, or `RESULTS_DIR` before calling `sbatch`.

## Combining partial outputs

```powershell
python scripts/combine_results.py results/local_test --output results/results_combined.parquet
```

## Evaluation

Generate the baseline summaries and plots used for the paper:

```powershell
python scripts/evaluate_results.py results/results_combined.parquet --output-dir analysis_output
```

This writes:

- `summary_statistics.csv`
- `method_rankings.csv`
- `results_table.csv`
- `results_table.tex`
- `baseline.json`
- core coverage plots

## Notebook

Open `notebooks/evaluate_results.ipynb` when you want an interactive pass over the combined results. The notebook reads from `results/` and uses the same analysis helpers as the command-line evaluation script.

## Notes on provenance

The original project used multiple cluster-specific driver scripts and a Colab notebook. This cleaned repository keeps the MPI and SLURM execution pattern but consolidates the simulation run into one Python file and one shell script.