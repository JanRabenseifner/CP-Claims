from __future__ import annotations

from dataclasses import dataclass, field


METHOD_DISPLAY_NAMES = {
    "DGCP_Exact_m10": "DGCP Exact m=10",
    "DGCP_Exact_m20": "DGCP Exact m=20",
    "DGCP_Exact_m50": "DGCP Exact m=50",
    "DGCP_Exact_m100": "DGCP Exact m=100",
    "DGCP_Exact_m200": "DGCP Exact m=200",
    "DGCP_Full_m10": "DGCP Full m=10",
    "DGCP_Full_m20": "DGCP Full m=20",
    "DGCP_Full_m50": "DGCP Full m=50",
    "DGCP_Full_m100": "DGCP Full m=100",
    "DGCP_Full_m200": "DGCP Full m=200",
    "DGCP_Hybrid_m10": "DGCP Hybrid m=10",
    "DGCP_Hybrid_m20": "DGCP Hybrid m=20",
    "DGCP_Hybrid_m50": "DGCP Hybrid m=50",
    "DGCP_Hybrid_m100": "DGCP Hybrid m=100",
    "DGCP_Hybrid_m200": "DGCP Hybrid m=200",
    "Poisson_Normal": "Parametric Poisson",
    "Poisson_Bootstrap": "Bootstrap Poisson",
    "NB_Plugin": "NB Plugin",
    "NB_PlugIn": "NB Plugin",
    "NB_Chebyshev": "NB Chebyshev",
    "NB_Bootstrap": "NB Bootstrap",
    "ICP_poisson_deviance": "Standard ICP",
    "ICP_za_relative": "ZA Relative ICP",
    "Mondrian_Poisson": "Cluster Cond. ICP",
    "Binary_CP_Marginal": "Binary CP Marginal",
    "Binary_CP_Mondrian": "Binary CP Mondrian",
    "Two_Stage_Weighted_CP": "Two Stage Weighted CP",
    "Two_Stage_Calibrated_CP": "Two Stage Calibrated CP",
    "Two_Stage_Balanced_V2_CP": "Two Stage Balanced V2 CP",
    "Two_Stage_Direct_CP": "Two Stage Direct CP",
    "Two_Stage_Empirical_CP": "Two Stage Empirical CP",
    "Two_Stage_Exact_CP": "Two Stage Exact CP",
}

BENCHMARK_METHODS = [
    "Poisson_Normal",
    "Poisson_Bootstrap",
    "NB_Plugin",
    "NB_Chebyshev",
    "NB_Bootstrap",
]

CP_METHODS = [
    "ICP_poisson_deviance",
    "ICP_za_relative",
    "Mondrian_Poisson",
    "Binary_CP_Marginal",
]

DEFAULT_MAIN_METHODS = [
    "DGCP_Hybrid_m200",
    "DGCP_Full_m200",
    "Poisson_Normal",
    "Poisson_Bootstrap",
    "NB_Plugin",
    "NB_Chebyshev",
    "NB_Bootstrap",
    "ICP_poisson_deviance",
    "ICP_za_relative",
    "Mondrian_Poisson",
]

DEFAULT_BASELINE_DESIRED = {
    "interaction_effects": True,
    "spatial_effects": False,
    "n_obs": 10000,
    "dim_x": 10,
    "correlation_strength": 0.3,
    "categorical_ratio": 0.3,
}


@dataclass
class SimulationGrid:
    dgp_types: list[str] = field(default_factory=lambda: ["poisson", "zip", "negbin", "hurdle"])
    n_obs: list[int] = field(default_factory=lambda: [1000, 2000, 4000, 6000, 10000])
    dim_x: list[int] = field(default_factory=lambda: [10, 20, 50])
    correlation_type: list[str] = field(default_factory=lambda: ["toeplitz"])
    correlation_strength: list[float] = field(default_factory=lambda: [0.0, 0.3, 0.5])
    categorical_ratio: list[float] = field(default_factory=lambda: [0.1, 0.3, 0.5])
    exposure_type: list[str] = field(default_factory=lambda: ["realistic"])
    interaction_effects: list[bool] = field(default_factory=lambda: [False, True])
    spatial_effects: list[bool] = field(default_factory=lambda: [False, True])
