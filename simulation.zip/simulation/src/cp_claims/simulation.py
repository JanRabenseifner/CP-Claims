from __future__ import annotations

import itertools
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OrdinalEncoder

from .utils_benchmarks import run_parametric_benchmarks
from .utils_dgcp import two_stage_dgcp_cp
from .utils_dgps import EnhancedCountDGP, split_data, summarize_dgp_output
from .utils_eval import interval_score
from .utils_pinterval import (
    binary_classification_cp,
    discrete_conformal_poisson,
    mondrian_conformal_poisson,
)

try:
    from lightgbm import LGBMRegressor

    LGBM_AVAILABLE = True
except ImportError:
    LGBM_AVAILABLE = False


@dataclass(frozen=True)
class SimulationConfig:
    dgp_type: str
    n_obs: int
    dim_x: int
    correlation_strength: float
    categorical_ratio: float
    interaction_effects: bool
    spatial_effects: bool
    zero_inflation: float
    overdispersion: float
    repetition: int
    seed: int
    exposure_type: str = "realistic"
    correlation_type: str = "toeplitz"


DEFAULT_PARAM_GRID = {
    "dgp_type": ["poisson", "zip", "negbin", "hurdle"],
    "n_obs": [1000, 2000, 4000, 6000, 10000],
    "dim_x": [10, 20, 50],
    "correlation_strength": [0.0, 0.3, 0.5],
    "categorical_ratio": [0.1, 0.3, 0.5],
    "interaction_effects": [False, True],
    "spatial_effects": [False, True],
}


def generate_default_configs(n_reps: int = 5, base_seed: int = 42) -> list[SimulationConfig]:
    configs: list[SimulationConfig] = []
    keys = list(DEFAULT_PARAM_GRID.keys())
    for repetition in range(n_reps):
        for index, values in enumerate(itertools.product(*(DEFAULT_PARAM_GRID[key] for key in keys))):
            config = dict(zip(keys, values))
            config["zero_inflation"] = [0.0, 0.1, 0.3, 0.5][index % 4] if config["dgp_type"] in {"zip", "hurdle"} else 0.0
            config["overdispersion"] = [2.0, 3.0, 4.0, 5.0][index % 4] if config["dgp_type"] == "negbin" else 1.0
            config["repetition"] = repetition
            config["seed"] = base_seed + repetition * 10_000 + index
            configs.append(SimulationConfig(**config))
    return configs


def _fit_poisson_glm(train_data: pd.DataFrame, valid_vars: list[str]):
    design = pd.get_dummies(train_data[valid_vars], drop_first=True, dtype=float)
    design = sm.add_constant(design)
    model = sm.GLM(train_data["Claims"], design, family=sm.families.Poisson(), exposure=train_data["Exposure"])
    result = model.fit(maxiter=100)

    def predict(data_subset: pd.DataFrame) -> np.ndarray:
        design_subset = pd.get_dummies(data_subset[valid_vars], drop_first=True, dtype=float)
        design_subset = sm.add_constant(design_subset)
        for column in result.model.exog_names:
            if column not in design_subset.columns:
                design_subset[column] = 0
        design_subset = design_subset[result.model.exog_names]
        return np.clip(result.predict(design_subset) * data_subset["Exposure"].values, 1e-6, 100)

    return predict


def _fit_lgbm(train_data: pd.DataFrame, valid_vars: list[str]):
    if not LGBM_AVAILABLE:
        raise ImportError("lightgbm is not installed")
    numeric_columns = [column for column in valid_vars if np.issubdtype(train_data[column].dtype, np.number)]
    categorical_columns = [column for column in valid_vars if column not in numeric_columns]
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", "passthrough", numeric_columns),
            ("cat", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1), categorical_columns),
        ],
        verbose_feature_names_out=False,
    ).set_output(transform="pandas")
    features = preprocessor.fit_transform(train_data[valid_vars])
    target = train_data["Claims"] / train_data["Exposure"]
    model = LGBMRegressor(
        objective="poisson",
        learning_rate=0.05,
        num_leaves=31,
        reg_lambda=2.0,
        reg_alpha=2.0,
        n_estimators=200,
        random_state=42,
        verbosity=-1,
    )
    model.fit(features, target, sample_weight=train_data["Exposure"])

    def predict(data_subset: pd.DataFrame) -> np.ndarray:
        transformed = preprocessor.transform(data_subset[valid_vars])
        return np.clip(model.predict(transformed) * data_subset["Exposure"].values, 1e-6, 100)

    return predict


def _fit_random_forest(train_data: pd.DataFrame, valid_vars: list[str]):
    numeric_columns = [column for column in valid_vars if np.issubdtype(train_data[column].dtype, np.number)]
    categorical_columns = [column for column in valid_vars if column not in numeric_columns]
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", "passthrough", numeric_columns),
            ("cat", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1), categorical_columns),
        ],
        verbose_feature_names_out=False,
    ).set_output(transform="pandas")
    features = preprocessor.fit_transform(train_data[valid_vars])
    target = train_data["Claims"] / train_data["Exposure"]
    model = RandomForestRegressor(
        criterion="poisson",
        n_estimators=100,
        max_features="sqrt",
        max_depth=10,
        min_samples_leaf=20,
        random_state=42,
        n_jobs=1,
    )
    model.fit(features, target, sample_weight=train_data["Exposure"])

    def predict(data_subset: pd.DataFrame) -> np.ndarray:
        transformed = preprocessor.transform(data_subset[valid_vars])
        return np.clip(model.predict(transformed) * data_subset["Exposure"].values, 1e-6, 100)

    return predict


LEARNERS = {
    "Poisson_GLM": _fit_poisson_glm,
    "LightGBM": _fit_lgbm,
    "RandomForest": _fit_random_forest,
}


def _binary_sets_to_bounds(pred_mu: np.ndarray, prediction_sets: list[set[int]]) -> tuple[np.ndarray, np.ndarray]:
    lower = np.zeros(len(prediction_sets))
    upper = np.zeros(len(prediction_sets))
    for index, (set_values, mu_value) in enumerate(zip(prediction_sets, pred_mu)):
        if 0 in set_values and 1 in set_values:
            lower[index] = 0
            upper[index] = max(1, int(np.ceil(mu_value + 4 * np.sqrt(max(mu_value, 1e-6)))))
        elif 0 in set_values:
            lower[index] = 0
            upper[index] = 0
        else:
            lower[index] = 1
            upper[index] = max(1, int(np.ceil(mu_value + 4 * np.sqrt(max(mu_value, 1e-6)))))
    return lower, upper


def _compute_metrics(y_true: np.ndarray, lower: np.ndarray, upper: np.ndarray, pred_mu: np.ndarray, alpha: float) -> dict[str, float]:
    covered = (y_true >= lower) & (y_true <= upper)
    widths = upper - lower
    metrics = {
        "coverage": float(np.mean(covered)),
        "mean_width": float(np.mean(widths)),
        "median_width": float(np.median(widths)),
        "interval_score": float(interval_score(y_true, lower, upper, alpha)),
        "pct_singleton": float(100 * np.mean(widths == 0)),
        "risk_differentiation": float(np.corrcoef(pred_mu, widths)[0, 1]) if len(pred_mu) > 1 and np.std(widths) > 0 else np.nan,
    }
    groups = {
        "coverage_y0": y_true == 0,
        "coverage_y1": y_true == 1,
        "coverage_y2plus": y_true >= 2,
        "coverage_y1_5": (y_true >= 1) & (y_true <= 5),
        "coverage_y6_10": (y_true >= 6) & (y_true <= 10),
        "coverage_y11_20": (y_true >= 11) & (y_true <= 20),
        "coverage_y21_50": (y_true >= 21) & (y_true <= 50),
        "coverage_y51plus": y_true >= 51,
    }
    for label, mask in groups.items():
        metrics[label] = float(np.mean(covered[mask])) if mask.sum() >= 5 else np.nan
    metrics["coverage_gap"] = abs(metrics["coverage_y0"] - metrics["coverage_y1"]) if not np.isnan(metrics["coverage_y0"]) and not np.isnan(metrics["coverage_y1"]) else np.nan
    metrics["pct_informative"] = float(100 * np.mean((lower > 0) | (upper > 1)))
    return metrics


def run_single_simulation(config: SimulationConfig, alpha: float = 0.1) -> list[dict[str, object]]:
    dgp = EnhancedCountDGP(seed=config.seed)
    features = dgp.generate_covariates(
        n_obs=config.n_obs,
        dim_x=config.dim_x,
        correlation_type=config.correlation_type,
        categorical_ratio=config.categorical_ratio,
        correlation_strength=config.correlation_strength,
    )
    exposure = dgp.generate_exposure(n_obs=config.n_obs, exposure_type=config.exposure_type)
    y, mu_true, _ = dgp.generate_claims(
        df=features,
        exposure=exposure,
        dgp_type=config.dgp_type,
        zero_inflation=config.zero_inflation,
        overdispersion=config.overdispersion,
        interaction_effects=config.interaction_effects,
        spatial_effects=config.spatial_effects,
    )
    features["Claims"] = y
    features["Exposure"] = exposure
    features["pred_mu_true"] = mu_true
    splits = split_data({"df": features, "params": asdict(config)}, seed=config.seed)
    train_data = splits["train"]
    calib_data = splits["calib"]
    test_data = splits["test"]
    valid_vars = [column for column in train_data.columns if column not in {"Claims", "Exposure", "pred_mu_true", "pi_true"}]
    results: list[dict[str, object]] = []
    dgp_summary = summarize_dgp_output({"y": y, "mu": mu_true})

    for learner_name, fit_learner in LEARNERS.items():
        if learner_name == "LightGBM" and not LGBM_AVAILABLE:
            continue
        predict = fit_learner(train_data, valid_vars)
        calib_mu = predict(calib_data.copy())
        pred_mu = predict(test_data.copy())
        calib_y = calib_data["Claims"].to_numpy()
        test_y = test_data["Claims"].to_numpy()
        calib_binary = (calib_y > 0).astype(int)
        pred_probs = np.column_stack([np.exp(-pred_mu), 1 - np.exp(-pred_mu)])
        calib_probs = np.column_stack([np.exp(-calib_mu), 1 - np.exp(-calib_mu)])

        method_outputs: dict[str, object] = {
            "ICP_poisson_deviance": discrete_conformal_poisson(pred_mu, calib_mu, calib_y, alpha, "poisson_deviance"),
            "ICP_za_relative": discrete_conformal_poisson(pred_mu, calib_mu, calib_y, alpha, "za_relative"),
            "Mondrian_Poisson": mondrian_conformal_poisson(pred_mu, np.ones(len(pred_mu)), calib_mu, calib_y, np.ones(len(calib_mu)), alpha, "poisson_deviance"),
            "Binary_CP_Marginal": binary_classification_cp(pred_probs, calib_probs, calib_binary, alpha, mondrian=False),
            "Binary_CP_Mondrian": binary_classification_cp(pred_probs, calib_probs, calib_binary, alpha, mondrian=True),
            "DGCP_Hybrid_m200": two_stage_dgcp_cp(pred_mu, calib_mu, calib_y, alpha=alpha, ncs_type="poisson_deviance", min_group_size=200, method="hybrid"),
            "DGCP_Full_m200": two_stage_dgcp_cp(pred_mu, calib_mu, calib_y, alpha=alpha, ncs_type="poisson_deviance", min_group_size=200, method="full"),
        }
        if learner_name == "Poisson_GLM":
            method_outputs.update({key: value for key, value in run_parametric_benchmarks(train_data, calib_data, test_data, valid_vars, alpha=alpha).items() if not key.startswith("_")})

        for method_name, output in method_outputs.items():
            if output is None:
                continue
            if method_name.startswith("Binary_"):
                lower, upper = _binary_sets_to_bounds(pred_mu, output)
            else:
                lower = output["lower"].to_numpy() if "lower" in output.columns else output["lower_bound"].to_numpy()
                upper = output["upper"].to_numpy() if "upper" in output.columns else output["upper_bound"].to_numpy()
            row = {
                "method": method_name,
                "learner": learner_name,
                **asdict(config),
                **_compute_metrics(test_y, lower, upper, pred_mu, alpha),
                "min_group_size": 200 if method_name.startswith("DGCP_") else np.nan,
                "pct_zeros_data": dgp_summary["pct_zeros"],
                "mean_y_data": dgp_summary["mean_y"],
                "var_y_data": dgp_summary["var_y"],
                "dispersion_ratio": dgp_summary["dispersion_ratio"],
            }
            results.append(row)
    return results


def run_simulation(configs: list[SimulationConfig], output_path: Path, alpha: float = 0.1) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for config in configs:
        rows.extend(run_single_simulation(config, alpha=alpha))
    result_frame = pd.DataFrame(rows)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    result_frame.to_parquet(output_path, index=False)
    return result_frame