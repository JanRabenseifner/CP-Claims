from __future__ import annotations

import argparse
from pathlib import Path

from .analysis import (
    DEFAULT_METHODS,
    apply_baseline_filter,
    compute_method_rankings,
    compute_summary_stats,
    filter_methods,
    infer_baseline,
    load_results,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate combined simulation outputs and save summary tables.")
    parser.add_argument("input", nargs="+", help="Combined result file or directories with result files.")
    parser.add_argument("--output-dir", type=Path, default=Path("analysis_output"), help="Directory for summary CSV files.")
    args = parser.parse_args()

    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    df = load_results(args.input)
    df = filter_methods(df, DEFAULT_METHODS)
    baseline = infer_baseline(df)
    df_baseline = apply_baseline_filter(df, baseline)

    summary = compute_summary_stats(df_baseline)
    rankings = compute_method_rankings(df_baseline)
    method_summary = df_baseline.groupby("method").agg({"coverage": "mean", "mean_width": "mean"}).round(4)

    summary.to_csv(output_dir / "summary_statistics.csv", index=False)
    rankings.to_csv(output_dir / "method_rankings.csv", index=False)
    method_summary.to_csv(output_dir / "method_summary.csv")
    (output_dir / "baseline.json").write_text(str(baseline), encoding="utf-8")

    print(f"Baseline rows: {len(df_baseline):,}")
    print(f"Saved summary_statistics.csv, method_rankings.csv, and method_summary.csv to {output_dir}")


if __name__ == "__main__":
    main()