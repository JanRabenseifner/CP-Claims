from __future__ import annotations

import argparse
from pathlib import Path

from .simulation import generate_default_configs, run_simulation


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the count-data conformal prediction simulation study.")
    parser.add_argument("--reps", type=int, default=2, help="Number of repetitions for each parameter configuration.")
    parser.add_argument("--output", type=Path, default=Path("results") / "results.parquet", help="Output parquet file.")
    args = parser.parse_args()

    configs = generate_default_configs(n_reps=args.reps)
    results = run_simulation(configs, args.output)
    print(f"Saved {len(results):,} rows to {args.output}")


if __name__ == "__main__":
    main()